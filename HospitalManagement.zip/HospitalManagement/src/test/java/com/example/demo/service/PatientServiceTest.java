package com.example.demo.service;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Patient;
import com.example.demo.repo.PatientRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.Optional;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class PatientServiceTest {

    @Mock
    private PatientRepository patientRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private PatientService patientService;

    private Patient mockPatient;

    @Before
    public void setUp() {
        mockPatient = new Patient();
        mockPatient.setPatientId(1);
        mockPatient.setFullName("Alice Smith");
        mockPatient.setEmailAddress("alice@example.com");
        mockPatient.setLoginPassword("plaintextPassword");
        mockPatient.setGender("Female");
        mockPatient.setMobileNumber("1234567890");
        mockPatient.setDateOfBirth(Date.valueOf("2000-01-01"));
        mockPatient.setResidentialAddress("123 Main Street");
    }

    @Test
    public void testAddPatient() {
        when(passwordEncoder.encode(anyString())).thenReturn("encodedPassword");
        when(patientRepository.save(any(Patient.class))).thenAnswer(i -> i.getArguments()[0]);

        Patient saved = patientService.addPatient(mockPatient);

        assertEquals("encodedPassword", saved.getLoginPassword());
        assertFalse(saved.isAdmitted());
        assertNotNull(saved.getRegisteredOn());
        verify(patientRepository, times(1)).save(any(Patient.class));
    }

    @Test
    public void testUpdatePatient() {
        mockPatient.setLoginPassword("oldPassword");
        when(patientRepository.findById(1)).thenReturn(Optional.of(mockPatient));
        when(passwordEncoder.encode("newPassword")).thenReturn("encodedNewPassword");
        when(patientRepository.save(any(Patient.class))).thenAnswer(i -> i.getArguments()[0]);

        Patient updated = new Patient();
        updated.setFullName("Alice Updated");
        updated.setEmailAddress("updated@example.com");
        updated.setMobileNumber("9876543210");
        updated.setResidentialAddress("Updated Address");
        updated.setDateOfBirth(Date.valueOf("1999-12-31"));
        updated.setGender("Female");
        updated.setLoginPassword("newPassword");

        Patient result = patientService.updatePatient(1, updated);
        assertEquals("Alice Updated", result.getFullName());
        assertEquals("encodedNewPassword", result.getLoginPassword());
        verify(patientRepository, times(1)).save(any(Patient.class));
    }

    @Test
    public void testAuthenticate_Success() {
        mockPatient.setLoginPassword("encodedPassword");
        when(patientRepository.findByEmailAddress("alice@example.com")).thenReturn(Optional.of(mockPatient));
        when(passwordEncoder.matches("plaintextPassword", "encodedPassword")).thenReturn(true);

        boolean isAuthenticated = patientService.authenticate("alice@example.com", "plaintextPassword");
        assertTrue(isAuthenticated);
    }

    @Test
    public void testAuthenticate_Failure() {
        mockPatient.setLoginPassword("encodedPassword");
        when(patientRepository.findByEmailAddress("alice@example.com")).thenReturn(Optional.of(mockPatient));
        when(passwordEncoder.matches("wrongPassword", "encodedPassword")).thenReturn(false);

        boolean isAuthenticated = patientService.authenticate("alice@example.com", "wrongPassword");
        assertFalse(isAuthenticated);
    }

    @Test
    public void testGetPatientByEmailAddress_Found() {
        when(patientRepository.findByEmailAddress("alice@example.com")).thenReturn(Optional.of(mockPatient));
        Patient result = patientService.getPatientByEmailAddress("alice@example.com");

        assertNotNull(result);
        assertEquals("Alice Smith", result.getFullName());
    }

    @Test(expected = ResourceNotFoundException.class)
    public void testGetPatientByEmailAddress_NotFound() {
        when(patientRepository.findByEmailAddress("notfound@example.com")).thenReturn(Optional.empty());
        patientService.getPatientByEmailAddress("notfound@example.com");
    }
}

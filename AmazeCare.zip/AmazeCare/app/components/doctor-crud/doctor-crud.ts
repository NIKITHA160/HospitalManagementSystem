import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { Doctor } from '../../model/doctor';
import { AdminService } from '../../service/admin-service';

@Component({
  selector: 'app-doctor-crud',
  standalone: true,
  templateUrl: './doctor-crud.html',
  styleUrl: './doctor-crud.css',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatInputModule,
    MatButtonModule
  ]
})
export class DoctorCrudComponent implements OnInit {
  displayedColumns: string[] = ['id', 'name', 'department', 'email', 'mobile', 'experience', 'hospitalId', 'actions'];
  dataSource = new MatTableDataSource<Doctor>([]);
  doctorForm!: FormGroup;
  isEditing = false;
  selectedDoctorId: number | null = null;
  filterValue = '';

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  constructor(private fb: FormBuilder, private adminService: AdminService) {}

  ngOnInit(): void {
    this.doctorForm = this.fb.group({
      fullName: ['', Validators.required],
      emailAddress: ['', [Validators.required, Validators.email]],
      mobileNumber: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      department: ['', Validators.required],
      designation: ['', Validators.required],
      qualification: ['', Validators.required],
      yearsOfExperience: ['', [Validators.required, Validators.min(0)]],
      hospitalId: ['', Validators.required],
      loginPassword: ['', Validators.required]
    });

    this.loadDoctors();
  }

  loadDoctors(): void {
    this.adminService.getAllDoctors().subscribe(data => {
      this.dataSource = new MatTableDataSource(data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.filterPredicate = (doctor: Doctor, filter: string) => {
        const str = (doctor.fullName + doctor.emailAddress + doctor.department).toLowerCase();
        return str.includes(filter.trim().toLowerCase());
      };
    });
  }

  applyFilter(): void {
    this.dataSource.filter = this.filterValue.trim().toLowerCase();
  }

  editDoctor(doctor: Doctor): void {
    this.isEditing = true;
    this.selectedDoctorId = doctor.doctorId;
    this.doctorForm.patchValue(doctor);
  }

  deleteDoctor(id: number): void {
    if (confirm('Are you sure you want to delete this doctor?')) {
      this.adminService.deleteDoctor(id).subscribe(() => this.loadDoctors());
    }
  }

  onSubmit(): void {
    if (this.doctorForm.invalid || this.selectedDoctorId === null) return;

    const doctorData: Doctor = this.doctorForm.value;

    this.adminService.updateDoctor(this.selectedDoctorId, doctorData).subscribe(() => {
      this.resetForm();
      this.loadDoctors();
    });
  }

  resetForm(): void {
    this.doctorForm.reset();
    this.isEditing = false;
    this.selectedDoctorId = null;
  }
}

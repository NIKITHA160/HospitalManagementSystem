import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DoctorCrud } from './doctor-crud';

describe('DoctorCrud', () => {
  let component: DoctorCrud;
  let fixture: ComponentFixture<DoctorCrud>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DoctorCrud]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DoctorCrud);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AdminService } from '../../../service/admin-service';
import { Admin } from '../../../model/admin';


@Component({
  selector: 'app-add-admin',
  standalone: true,
  imports: [FormsModule, ReactiveFormsModule, RouterModule, CommonModule],
  templateUrl: './add-admin.html',
  styleUrl: './add-admin.css'
})
export class AddAdminComponent implements OnInit {
  adminForm!: FormGroup;
  successMessage = '';
  errorMessage = '';

  constructor(
    private fb: FormBuilder,
    private adminService: AdminService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.adminForm = this.fb.group({
      fullName: ['', Validators.required],
      emailAddress: ['', [Validators.required, Validators.email]],
      loginPassword: ['', [Validators.required, Validators.minLength(6)]],
      contactNumber: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      registeredOn: ['', Validators.required]
    });
  }

  onSubmit(): void {
    if (this.adminForm.invalid) {
      this.errorMessage = 'Please fill in all required fields correctly.';
      return;
    }

    const formData = this.adminForm.value;

    const newAdmin: Admin = {
      adminId: 0, 
      fullName: formData.fullName,
      emailAddress: formData.emailAddress,
      loginPassword: formData.loginPassword,
      contactNumber: formData.contactNumber,
      registeredOn: new Date()
    };

    this.adminService.addAdmin(newAdmin).subscribe({
      next: () => {
        this.successMessage = 'Admin added successfully!';
        this.adminForm.reset();
        setTimeout(() => this.router.navigate(['/view-admins']), 1500);
      },
      error: (err) => {
        this.errorMessage = 'Failed to add admin. Try again.';
        console.error(err);
      }
    });
  }
}

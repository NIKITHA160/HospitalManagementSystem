import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminService } from '../../service/admin-service';
import { Appointment } from '../../model/appointment';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-active-appointments',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './active-appointments.html',
  styleUrls: ['./active-appointments.css']
})
export class ActiveAppointmentsComponent implements OnInit {
  appointments: Appointment[] = [];
  error: string = '';

  constructor(private adminService: AdminService) {}

  ngOnInit(): void {
    this.adminService.getAllAppointments().subscribe({
      next: (data) => {
        this.appointments = data.filter(a => a.status !== 'cancelled');
      },
      error: (err) => {
        console.error(err);
        this.error = 'Failed to load active appointments.';
      }
    });
  }
}

import { CommonModule } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { Hospital } from '../../model/hospital';
import { AdminService } from '../../service/admin-service';

@Component({
  selector: 'app-hospital-crud',
  standalone: true,
  templateUrl: './hospital-crud.html',
  styleUrls: ['./hospital-crud.css'],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatInputModule,
    MatButtonModule,
    MatFormFieldModule
  ]
})
export class HospitalCrudComponent implements OnInit {
  displayedColumns: string[] = ['id', 'name', 'city', 'location', 'contact', 'registeredOn', 'actions'];
  dataSource = new MatTableDataSource<Hospital>([]);
  hospitalForm!: FormGroup;
  isEditing = false;
  selectedHospitalId: number | null = null;
  filterValue = '';

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  constructor(private adminService: AdminService, private fb: FormBuilder) {}

  ngOnInit(): void {
    this.hospitalForm = this.fb.group({
      hospitalName: ['', Validators.required],
      cityName: ['', Validators.required],
      locationArea: ['', Validators.required],
      contactNumber: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      registeredOn: ['', Validators.required]
    });
    this.loadHospitals();
  }

  loadHospitals(): void {
    this.adminService.getHospitalsByCity('All').subscribe({
      next: (data) => {
        this.dataSource = new MatTableDataSource(data);
        this.dataSource.paginator = this.paginator;
        this.dataSource.filterPredicate = (h: Hospital, filter: string) =>
          (h.hospitalName + h.cityName + h.locationArea).toLowerCase().includes(filter.trim().toLowerCase());
      },
      error: (err) => console.error('Error loading hospitals:', err)
    });
  }

  applyFilter(): void {
    this.dataSource.filter = this.filterValue.trim().toLowerCase();
  }

  editHospital(hospital: Hospital): void {
    this.isEditing = true;
    this.selectedHospitalId = hospital.hospitalId;
    this.hospitalForm.patchValue(hospital);
  }

  deleteHospital(id: number): void {
    if (confirm('Are you sure you want to delete this hospital?')) {
      this.adminService.deleteHospital(id).subscribe({
        next: () => this.loadHospitals(),
        error: (err) => console.error('Delete failed:', err)
      });
    }
  }

  onSubmit(): void {
    if (this.hospitalForm.invalid) return;

    const hospitalData: Hospital = {
      ...this.hospitalForm.value,
      hospitalId: this.selectedHospitalId ?? 0 
    };

    console.log('Submitting hospital data:', hospitalData);

    if (this.isEditing && this.selectedHospitalId !== null) {
      this.adminService.updateHospital(this.selectedHospitalId, hospitalData).subscribe({
        next: () => {
          this.resetForm();
          this.loadHospitals();
        },
        error: (err) => console.error('Update failed:', err)
      });
    } else {
      this.adminService.addHospital(hospitalData).subscribe({
        next: () => {
          this.resetForm();
          this.loadHospitals();
        },
        error: (err) => console.error('Add failed:', err)
      });
    }
  }

  resetForm(): void {
    this.hospitalForm.reset();
    this.isEditing = false;
    this.selectedHospitalId = null;
  }
}

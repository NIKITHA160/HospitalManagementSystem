package com.example.demo.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "admin")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Admin {

    public int getAdminId() {
		return adminId;
	}

	public String getFullName() {
		return fullName;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public String getLoginPassword() {
		return loginPassword;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public java.sql.Timestamp getRegisteredOn() {
		return registeredOn;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public void setRegisteredOn(java.sql.Timestamp registeredOn) {
		this.registeredOn = registeredOn;
	}

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int adminId;

    private String fullName;
    private String emailAddress;
    private String loginPassword;
    private String contactNumber;

    @Column(name = "registered_on")
    private java.sql.Timestamp registeredOn;
}


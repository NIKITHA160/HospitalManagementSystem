package com.example.demo.repo;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.model.Doctor;

public interface DoctorRepository extends JpaRepository<Doctor, Integer> {
    List<Doctor> findByDepartment(String department);
    List<Doctor> findByFullNameContainingIgnoreCase(String fullName);
    Doctor findByEmailAddress(String emailAddress);
    Doctor findByEmailAddressAndLoginPassword(String emailAddress, String loginPassword);
    List<Doctor> findByHospitalId(Long hospitalId);
    
}

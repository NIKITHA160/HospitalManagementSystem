import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { Doctor } from '../../model/doctor';
import { AdminService } from '../../service/admin-service';


@Component({
  selector: 'app-add-doctor',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './add-doctor.html',
  styleUrls: ['./add-doctor.css']
})
export class AddDoctorComponent {
  doctor: Doctor = new Doctor();
  message: string = '';

  constructor(private adminService: AdminService) {}

  addDoctor() {
    this.adminService.addDoctor(this.doctor).subscribe({
      next: () => {
        this.message = 'Doctor added successfully!';
        this.doctor = new Doctor();
      },
      error: () => {
        this.message = 'Failed to add doctor. Please try again.';
      }
    });
  }
}

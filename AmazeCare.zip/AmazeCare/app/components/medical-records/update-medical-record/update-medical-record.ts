import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { DoctorService } from '../../../service/doctor-service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-update-medical-record',
  imports: [RouterModule,CommonModule,FormsModule,ReactiveFormsModule],
  templateUrl: './update-medical-record.html',
  styleUrl: './update-medical-record.css'
})
export class UpdateMedicalRecordComponent implements OnInit {
  form: FormGroup;
  recordId!: number;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private doctorService: DoctorService,
    private fb: FormBuilder
  ) {
    this.form = this.fb.group({
      patientId: [''],
      appointmentId: [''],
      prescriptionId: [''],
      diagnosis: ['']
    });
  }

  ngOnInit(): void {
    this.recordId = +this.route.snapshot.paramMap.get('id')!;
    this.doctorService.getMedicalRecordById(this.recordId).subscribe(record => {
      this.form.patchValue(record);
    });
  }

  onUpdate() {
    this.doctorService.updateMedicalRecord(this.recordId, this.form.value).subscribe(() => {
      alert('Record updated!');
      this.router.navigate(['/view-medical-history']);
    });
  }
}
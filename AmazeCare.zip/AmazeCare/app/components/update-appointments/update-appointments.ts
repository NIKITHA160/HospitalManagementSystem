import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AdminService } from '../../service/admin-service';
import { Appointment, AppointmentStatus } from '../../model/appointment';

@Component({
  selector: 'app-update-appointment',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule],
  templateUrl: './update-appointments.html',
  styleUrls: ['./update-appointments.css']
})
export class UpdateAppointmentComponent implements OnInit {
  appointmentForm!: FormGroup;
  appointmentId!: number;
  message: string = '';

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private adminService: AdminService
  ) {}

  ngOnInit(): void {
    this.appointmentId = +this.route.snapshot.paramMap.get('id')!;
    this.initForm();

    this.adminService.getAppointmentById(this.appointmentId).subscribe({
      next: (data) => this.appointmentForm.patchValue(data),
      error: () => this.message = 'Failed to load appointment.'
    });
  }

  initForm(): void {
    this.appointmentForm = this.fb.group({
      patientId: ['', [Validators.required, Validators.pattern('^[0-9]+$')]],
      doctorId: ['', [Validators.required, Validators.pattern('^[0-9]+$')]],
      preferredDatetime: ['', Validators.required],
      symptoms: ['', Validators.required],
      natureOfVisit: ['', Validators.required],
      status: [AppointmentStatus.pending, Validators.required]
    });
  }

  onSubmit(): void {
    if (this.appointmentForm.valid) {
      const updatedAppointment: Appointment = this.appointmentForm.value;
      this.adminService.updateAppointment(this.appointmentId, updatedAppointment).subscribe({
        next: () => {
          this.message = 'Appointment updated successfully!';
          this.router.navigate(['/view-appointments']);
        },
        error: (err) => {
          console.error(err);
          this.message = 'Error updating appointment.';
        }
      });
    } else {
      this.message = 'Please fill all required fields correctly.';
    }
  }
}

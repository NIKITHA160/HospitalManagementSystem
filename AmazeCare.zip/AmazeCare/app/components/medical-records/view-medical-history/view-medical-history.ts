import { Component } from '@angular/core';
import { MedicalHistory } from '../../../model/medical-history';
import { DoctorService } from '../../../service/doctor-service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-view-medical-history',
  imports: [FormsModule,CommonModule,RouterModule],
  templateUrl: './view-medical-history.html',
  styleUrl: './view-medical-history.css'
})
export class ViewMedicalHistoryComponent {
  patientId = '';
  records: MedicalHistory[] = [];

  constructor(private doctorService: DoctorService) {}

  searchByPatient() {
    this.doctorService.getMedicalHistoryByPatientId(+this.patientId).subscribe(data => {
      this.records = data;
    });
  }

  deleteRecord(id: number) {
    if (confirm('Are you sure you want to delete this record?')) {
      this.doctorService.deleteMedicalRecord(id).subscribe(() => {
        this.records = this.records.filter(r => r.recordId !== id);
      });
    }
  }
}
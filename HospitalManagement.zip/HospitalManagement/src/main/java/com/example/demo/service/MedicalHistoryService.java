package com.example.demo.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.model.MedicalHistory;
import com.example.demo.repo.MedicalHistoryRepository;

@Service
public class MedicalHistoryService {

    @Autowired
    private MedicalHistoryRepository medicalHistoryRepository;

    public MedicalHistory addMedicalRecord(MedicalHistory record) {
          return medicalHistoryRepository.save(record);
    }

    public List<MedicalHistory> getMedicalHistoryByPatient(int patientId) {
        return medicalHistoryRepository.findByPatientId(patientId);
    }
    public MedicalHistory updateMedicalRecord(int id, MedicalHistory updatedRecord) {
        MedicalHistory existing = medicalHistoryRepository.findById(id).orElse(null);
        if (existing == null) {
            return null;
        }
        existing.setPatientId(updatedRecord.getPatientId());
        existing.setAppointmentId(updatedRecord.getAppointmentId());
        existing.setPrescriptionId(updatedRecord.getPrescriptionId());
        existing.setDiagnosis(updatedRecord.getDiagnosis());
        return medicalHistoryRepository.save(existing);
    }

    public boolean deleteMedicalRecord(int id) {
        if (medicalHistoryRepository.existsById(id)) {
            medicalHistoryRepository.deleteById(id);
            return true;
        }
        return false;
    }

    public MedicalHistory getMedicalRecordById(int id) {
        return medicalHistoryRepository.findById(id).orElse(null);
    }



}

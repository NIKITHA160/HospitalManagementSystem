import { Component, OnInit } from '@angular/core';
import { Admin } from '../../../model/admin';
import { AdminService } from '../../../service/admin-service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-view-admins',
  imports: [FormsModule,CommonModule,RouterModule,ReactiveFormsModule],
  templateUrl: './view-admins.html',
  styleUrl: './view-admins.css'
})
export class ViewAdminsComponent implements OnInit {
  admins: Admin[] = [];
  errorMessage = '';

  constructor(private adminService: AdminService) {}

  ngOnInit(): void {
    this.fetchAdmins();
  }

  fetchAdmins(): void {
    this.adminService.getAllAdmins().subscribe({
      next: (data) => this.admins = data,
      error: (err) => {
        console.error('Error fetching admins:', err);
        this.errorMessage = 'Failed to load admins.';
      }
    });
  }
}

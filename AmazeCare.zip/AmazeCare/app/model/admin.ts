export class Admin {
  adminId: number;
  fullName: string;
  emailAddress: string;
  loginPassword: string;
  contactNumber: string;
  registeredOn: Date;
}

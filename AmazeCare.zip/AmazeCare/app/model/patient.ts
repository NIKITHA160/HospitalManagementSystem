export class Patient {
  patientId: number;
  fullName: string;
  dateOfBirth: Date;
  gender: string;
  mobileNumber: string;
  emailAddress: string;
  loginPassword: string;
  residentialAddress: string;
  registeredOn: Date;
  admitted: boolean;
}

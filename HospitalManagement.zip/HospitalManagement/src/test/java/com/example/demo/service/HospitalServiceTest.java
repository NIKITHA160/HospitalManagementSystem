package com.example.demo.service;

import com.example.demo.model.Hospital;
import com.example.demo.repo.HospitalRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.*;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class HospitalServiceTest {

    @Mock private HospitalRepository hospitalRepository;

    @InjectMocks private HospitalService hospitalService;

    private Hospital hospital;

    @Before
    public void setUp() {
        hospital = new Hospital();
        hospital.setHospitalId(1);
        hospital.setHospitalName("Amaze Hospital");
        hospital.setCityName("City");
        hospital.setLocationArea("Area");
    }

    @Test
    public void testAddHospital() {
        when(hospitalRepository.save(hospital)).thenReturn(hospital);
        Hospital result = hospitalService.addHospital(hospital);
        assertEquals("Amaze Hospital", result.getHospitalName());
    }

    @Test
    public void testDeleteHospital() {
        when(hospitalRepository.findById(1)).thenReturn(Optional.of(hospital));
        hospitalService.deleteHospital(1);
        verify(hospitalRepository).delete(hospital);
    }
}

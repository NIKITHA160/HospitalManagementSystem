package com.example.demo.model;



import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.*;

@Entity
@Table(name = "hospitals")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Hospital {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int hospitalId;

    private String hospitalName;
    private String cityName;
    private String locationArea;
    private String contactNumber;

    @Column(name = "registered_on")
    private java.sql.Timestamp registeredOn;

	public int getHospitalId() {
		return hospitalId;
	}

	public String getHospitalName() {
		return hospitalName;
	}

	public String getCityName() {
		return cityName;
	}

	public String getLocationArea() {
		return locationArea;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public java.sql.Timestamp getRegisteredOn() {
		return registeredOn;
	}

	public void setHospitalId(int hospitalId) {
		this.hospitalId = hospitalId;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public void setLocationArea(String locationArea) {
		this.locationArea = locationArea;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public void setRegisteredOn(java.sql.Timestamp registeredOn) {
		this.registeredOn = registeredOn;
	}
}

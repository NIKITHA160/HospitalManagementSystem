package com.example.demo.service;

import com.example.demo.model.Admin;
import com.example.demo.repo.AdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AdminService {

    @Autowired
    private AdminRepository adminRepository;

    public Admin addAdmin(Admin admin) {
        return adminRepository.save(admin);
    }

    public List<Admin> getAllAdmins() {
        return adminRepository.findAll();
    }

    public Optional<Admin> getAdminById(int id) {
        return adminRepository.findById(id);
    }

    public Admin getByEmail(String email) {
        return adminRepository.findByEmailAddress(email);
    }

    public Admin validateAdminLogin(String email, String password) {
        return adminRepository.findByEmailAddressAndLoginPassword(email, password);
    }
    public void deleteAdminById(int id) {
        adminRepository.deleteById(id);
    }
    public Admin updateAdmin(int id, Admin updatedAdmin) {
        return adminRepository.findById(id).map(existingAdmin -> {
            existingAdmin.setFullName(updatedAdmin.getFullName());
            existingAdmin.setEmailAddress(updatedAdmin.getEmailAddress());
            existingAdmin.setLoginPassword(updatedAdmin.getLoginPassword());
            existingAdmin.setContactNumber(updatedAdmin.getContactNumber());
            existingAdmin.setRegisteredOn(updatedAdmin.getRegisteredOn());
            return adminRepository.save(existingAdmin);
        }).orElse(null);
    }


}


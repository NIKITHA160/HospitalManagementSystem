package com.example.demo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.Hospital;

public interface HospitalRepository extends JpaRepository<Hospital, Integer> {
    List<Hospital> findByCityName(String cityName);
    List<Hospital> findByCityNameAndLocationArea(String cityName, String locationArea);
}

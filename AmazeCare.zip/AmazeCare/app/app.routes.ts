import { Routes } from '@angular/router';

import { LoginComponent } from './login/login';
import { AdminDashboard } from './admin-dashboard/admin-dashboard';
import { DoctorDashboard } from './doctor-dashboard/doctor-dashboard';


import { AddDoctorComponent } from './admin/add-doctor/add-doctor';
import { ViewDoctorsComponent } from './components/view-doctors/view-doctors';
import { ViewHospitalsComponent } from './components/view-hospitals/view-hospitals';
import { AddHospitalComponent } from './components/add-hospital/add-hospital';

import { AddAppointmentComponent } from './components/add-appointment/add-appointment';
import { ViewAppointmentsComponent } from './components/view-appointments/view-appointments';
import { UpdateAppointmentComponent } from './components/update-appointments/update-appointments';
import { ActiveAppointmentsComponent } from './components/active-appointments/active-appointments';
import { AddAdminComponent } from './components/admin/add-admin/add-admin';
import { ViewAdminsComponent } from './components/admin/view-admins/view-admins';
import { DoctorSearchComponent } from './components/doctor-search/doctor-search';
import { AppointmentSearchComponent } from './components/appointment-search/appointment-search';
import { AddMedicalRecordComponent } from './components/medical-records/add-medical-record/add-medical-record';
import { ViewMedicalHistoryComponent } from './components/medical-records/view-medical-history/view-medical-history';
import { SearchMedicalRecordComponent } from './components/medical-records/search-medical-record/search-medical-record';
import { UpdateMedicalRecordComponent } from './components/medical-records/update-medical-record/update-medical-record';
import { MedicalRecordsDashboardComponent } from './components/medical-records/medical-records-dashboard/medical-records-dashboard';
import { DoctorProfileComponent } from './components/doctor-profile/doctor-profile';
import { UpdatePatientComponent } from './components/patient/update-patient/update-patient';
import { PatientDashboardComponent } from './patient-dashboard/patient-dashboard';
import { BookAppointmentComponent } from './components/book-appointment/book-appointment';
import { ViewMyAppointmentsComponent } from './components/view-my-appointments/view-my-appointments';
import { ViewMyMedicalHistoryComponent } from './component/patient/view-my-medical-history/view-my-medical-history';
import { ViewDoctorsPatientComponent } from './components/patient/view-doctors-patient/view-doctors-patient';
import { ViewPatientProfileComponent } from './components/patient/view-patient-profile/view-patient-profile';

import { PatientViewHospitalsComponent } from './components/patient-view-hospitals/patient-view-hospitals';
import { DoctorSearchTableComponent } from './components/doctor-search-table/doctor-search-table';
import { AppointmentManagementComponent } from './components/appointment-management/appointment-management';
import { AdminCrudComponent } from './components/admin-crud/admin-crud';
import { DoctorCrudComponent } from './components/doctor-crud/doctor-crud';
import { HospitalCrudComponent } from './component/hospital-crud/hospital-crud';
import { NearbyHospitalsComponent } from './nearby-hospitals/nearby-hospitals';




export const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },

  
  { path: 'login', component: LoginComponent },

 
  { path: 'admin-dashboard', component: AdminDashboard },
  { path: 'doctor-dashboard', component: DoctorDashboard },
  { path: 'patient-dashboard', component: PatientDashboardComponent },


  
  { path: 'add-doctor', component: AddDoctorComponent },
  { path: 'view-doctors', component: ViewDoctorsComponent },

  
  { path: 'view-hospitals', component: ViewHospitalsComponent },
  { path: 'add-hospital', component: AddHospitalComponent },

 
  { path: 'add-appointment', component: AddAppointmentComponent },
  { path: 'view-appointments', component: ViewAppointmentsComponent } ,
  { path: 'update-appointment/:id', component: UpdateAppointmentComponent },
  { path: 'active-appointments', component: ActiveAppointmentsComponent },
  { path: 'add-admin', component: AddAdminComponent },
  { path: 'view-admins', component: ViewAdminsComponent },
  { path: 'search-doctor', component: DoctorSearchComponent },
   { path: 'appointment-search', component: AppointmentSearchComponent },
  
  { path: 'medical-records', component: MedicalRecordsDashboardComponent},
  { path: 'add-medical-record', component: AddMedicalRecordComponent },
  { path: 'view-medical-history', component: ViewMedicalHistoryComponent },
  { path: 'search-medical-record', component: SearchMedicalRecordComponent },
  { path: 'update-medical-record/:id', component: UpdateMedicalRecordComponent },
  { path: 'doctor-profile', component: DoctorProfileComponent },
   { path: 'update-patient/:id', component: UpdatePatientComponent },

   { path: 'patient-dashboard', component: PatientDashboardComponent },

{ path: 'book-appointment', component: BookAppointmentComponent },
{ path: 'view-my-appointments', component: ViewMyAppointmentsComponent },
{
  path: 'view-my-medical-history',
  component: ViewMyMedicalHistoryComponent
}
,
{ path: 'view-doctors-patient', component: ViewDoctorsPatientComponent },
{ path: 'view-patient-profile', component: ViewPatientProfileComponent },


{ path: 'view-all-hospitals', component: PatientViewHospitalsComponent },
{
  path: 'doctor-dashboard',
  component: DoctorDashboard,
  children: [
    { path: '', redirectTo: 'view-doctors', pathMatch: 'full' },
    { path: 'view-doctors', component: ViewDoctorsComponent },
    { path: 'search-doctor', component: DoctorSearchComponent },
    { path: 'view-appointments', component: ViewAppointmentsComponent },
    { path: 'appointment-search', component: AppointmentSearchComponent },
    { path: 'medical-records', component: MedicalRecordsDashboardComponent },
    { path: 'doctor-profile', component: DoctorProfileComponent }
  ]
},
{ path: 'view-doctors-new', component: DoctorSearchTableComponent },
{ path: 'appointment-management', component: AppointmentManagementComponent },
{ path: 'doctor-profile', component: DoctorProfileComponent },
{ path: 'admin-crud', component: AdminCrudComponent },
{ path: 'doctor-crud', component: DoctorCrudComponent },
{ path: 'hospital-crud', component: HospitalCrudComponent },
 { path: 'map', component: NearbyHospitalsComponent },





];


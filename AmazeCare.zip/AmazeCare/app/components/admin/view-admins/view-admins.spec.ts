import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAdmins } from './view-admins';

describe('ViewAdmins', () => {
  let component: ViewAdmins;
  let fixture: ComponentFixture<ViewAdmins>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ViewAdmins]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewAdmins);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

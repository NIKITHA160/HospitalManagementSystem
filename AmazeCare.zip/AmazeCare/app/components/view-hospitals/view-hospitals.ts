import { Component, OnInit } from '@angular/core';
import { Hospital } from '../../model/hospital';
import { AdminService } from '../../service/admin-service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-view-hospitals',
  imports: [FormsModule,CommonModule,RouterModule],
  templateUrl: './view-hospitals.html',
  styleUrl: './view-hospitals.css'
})
export class ViewHospitalsComponent implements OnInit {

  hospitals: Hospital[] = [];
  errorMessage: string = '';

  constructor(private adminService: AdminService) {}

  ngOnInit(): void {
    this.loadHospitals();
  }

  loadHospitals(): void {
    this.adminService.getHospitalsByCity('All').subscribe({
      next: (data) => {
        this.hospitals = data;
      },
      error: (err) => {
        this.errorMessage = 'Failed to load hospitals. Please try again later.';
        console.error(err);
      }
    });
  }
}
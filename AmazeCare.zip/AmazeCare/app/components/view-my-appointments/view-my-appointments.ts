import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PatientService } from '../../service/patient-service';
import { Appointment } from '../../model/appointment';
import { RouterModule } from '@angular/router';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

@Component({
  selector: 'app-view-my-appointments',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './view-my-appointments.html',
  styleUrl: './view-my-appointments.css',
})
export class ViewMyAppointmentsComponent implements OnInit {
  appointments: Appointment[] = [];
  errorMessage = '';
  loading = true;

  constructor(private patientService: PatientService) {}

  ngOnInit(): void {
    const email = localStorage.getItem('userEmail');
    if (!email) {
      this.errorMessage = 'User email not found in local storage.';
      this.loading = false;
      return;
    }

    this.patientService.getPatientByEmail(email).subscribe({
      next: (patient) => {
        const patientId = patient.patientId;
        this.fetchAppointments(patientId);
      },
      error: () => {
        this.errorMessage = 'Failed to load patient profile.';
        this.loading = false;
      }
    });
  }

  fetchAppointments(patientId: number): void {
    this.patientService.getAppointmentsByPatientId(patientId).subscribe({
      next: (data) => {
        this.appointments = data;
        this.loading = false;
      },
      error: () => {
        this.errorMessage = 'Failed to fetch appointments.';
        this.loading = false;
      }
    });
  }
  downloadAppointmentsPDF() {
  const DATA = document.getElementById('appointments-to-pdf');
  if (!DATA) return;

  html2canvas(DATA).then(canvas => {
    const imgWidth = 208; // A4 width in mm
    const pageHeight = 295; // A4 height in mm
    const imgHeight = canvas.height * imgWidth / canvas.width;
    let heightLeft = imgHeight;

    const contentDataURL = canvas.toDataURL('image/png');
    const pdf = new jsPDF('p', 'mm', 'a4');
    let position = 0;

    pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;

    while (heightLeft > 0) {
      position = heightLeft - imgHeight;
      pdf.addPage();
      pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
    }
    
    pdf.save('appointments.pdf');
  });
}

}

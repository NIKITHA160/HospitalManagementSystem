import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DoctorService } from '../../../service/doctor-service';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-add-medical-record',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule], 
  templateUrl: './add-medical-record.html',
  styleUrl: './add-medical-record.css'
})
export class AddMedicalRecordComponent {
  form: FormGroup;

  constructor(
    private fb: FormBuilder,
    private doctorService: DoctorService,
    private router: Router
  ) {
    this.form = this.fb.group({
      patientId: [''],
      appointmentId: [''],
      prescriptionId: [''],
      diagnosis: ['']
    });
  }

  onSubmit() {
    if (this.form.valid) {
      this.doctorService.addMedicalRecord(this.form.value).subscribe(() => {
        alert('Medical record added successfully');
        this.router.navigate(['/view-medical-history']);
      });
    }
  }
}

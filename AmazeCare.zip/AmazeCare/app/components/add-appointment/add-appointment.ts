import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AdminService } from '../../service/admin-service';
import { Appointment, AppointmentStatus } from '../../model/appointment';

@Component({
  selector: 'app-add-appointment',
  standalone: true,
  imports: [FormsModule, ReactiveFormsModule, RouterModule, CommonModule],
  templateUrl: './add-appointment.html',
  styleUrl: './add-appointment.css',
})
export class AddAppointmentComponent implements OnInit {
  appointmentForm!: FormGroup;
  successMessage = '';
  errorMessage = '';

  constructor(
    private fb: FormBuilder,
    private adminService: AdminService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.appointmentForm = this.fb.group({
      patientId: ['', Validators.required],
      doctorId: ['', Validators.required],
      preferredDate: ['', Validators.required],
      preferredTime: ['', Validators.required],
      natureOfVisit: ['', Validators.required],
      symptoms: ['', Validators.required],
    });
  }

  onSubmit(): void {
    if (this.appointmentForm.invalid) {
      this.errorMessage = 'Please fill in all required fields correctly.';
      return;
    }

    const formValues = this.appointmentForm.value;
    const preferredDatetime = new Date(`${formValues.preferredDate}T${formValues.preferredTime}`);

    const newAppointment: Appointment = {
      appointmentId: 0, 
      patientId: formValues.patientId,
      doctorId: formValues.doctorId,
      preferredDatetime: preferredDatetime,
      natureOfVisit: formValues.natureOfVisit,
      symptoms: formValues.symptoms,
      status: AppointmentStatus.pending 
    };

    this.adminService.addAppointment(newAppointment).subscribe({
      next: () => {
        this.successMessage = 'Appointment added successfully!';
        this.appointmentForm.reset();
        setTimeout(() => this.router.navigate(['/view-appointments']), 1000);
      },
      error: (err) => {
        this.errorMessage = 'Failed to add appointment. Try again.';
        console.error(err);
      }
    });
  }
}

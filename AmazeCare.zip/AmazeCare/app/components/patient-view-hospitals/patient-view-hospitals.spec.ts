import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PatientViewHospitals } from './patient-view-hospitals';

describe('PatientViewHospitals', () => {
  let component: PatientViewHospitals;
  let fixture: ComponentFixture<PatientViewHospitals>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PatientViewHospitals]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PatientViewHospitals);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

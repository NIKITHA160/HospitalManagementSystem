export class Doctor {
  doctorId?: number; 
  fullName: string;
  department: string;
  yearsOfExperience: number;
  qualification: string;
  designation: string;
  mobileNumber: string;
  emailAddress: string;
  loginPassword: string;
  registeredOn: Date;
  hospitalId: number;
}

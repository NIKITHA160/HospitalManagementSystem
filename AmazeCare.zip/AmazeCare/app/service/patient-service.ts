import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Patient } from '../model/patient';
import { Appointment } from '../model/appointment';
import { MedicalHistory } from '../model/medical-history';

@Injectable({
  providedIn: 'root'
})
export class PatientService {
  private baseUrl = 'http://localhost:8080/api/patients';

  constructor(private http: HttpClient) {}

  private getHeaders(): HttpHeaders {
    const token = localStorage.getItem('jwt');
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    });
  }

  
  addPatient(patient: Patient): Observable<Patient> {
    return this.http.post<Patient>(
      `${this.baseUrl}/add`,
      patient,
      { headers: this.getHeaders() }
    );
  }

 updatePatient(id: number, patient: Patient): Observable<Patient> {
  console.log('Sending update for patient ID:', id, patient); 
  return this.http.put<Patient>(
    `${this.baseUrl}/update/${id}`,
    patient,
    { headers: this.getHeaders() }
  );
}


  
  getPatientByEmail(email: string): Observable<Patient> {
  const encodedEmail = encodeURIComponent(email);
  return this.http.get<Patient>(
    `${this.baseUrl}/email/${encodedEmail}`,
    { headers: this.getHeaders() }
  );
}

  
  login(auth: { username: string; password: string }): Observable<any> {
    return this.http.post('http://localhost:8080/auth/generateToken', auth);
  }

  
  getById(id: number): Observable<Patient> {
    return this.http.get<Patient>(
      `${this.baseUrl}/${id}`,
      { headers: this.getHeaders() }
    );
  }
  getAppointmentsByPatientId(patientId: number): Observable<Appointment[]> {
  return this.http.get<Appointment[]>(
    `http://localhost:8080/appointment/patient/${patientId}`,
    { headers: this.getHeaders() }
  );
}

bookAppointment(appointment: Appointment): Observable<Appointment> {
  return this.http.post<Appointment>(
    'http://localhost:8080/addAppointment',
    appointment,
    { headers: this.getHeaders() }
  );
}
 getMyMedicalHistory(): Observable<MedicalHistory[]> {
    return this.http.get<MedicalHistory[]>(
      'http://localhost:8080/myMedicalHistory',
      { headers: this.getHeaders() }
    );
  }
  
getDoctorsByHospitalId(hospitalId: number): Observable<any[]> {
  return this.http.get<any[]>(
    `http://localhost:8080/showDoctorByHospital/${hospitalId}`,
    { headers: this.getHeaders() }
  );
}


}

import { MedicalHistory } from './medical-history';

describe('MedicalHistory', () => {
  it('should create an instance', () => {
    expect(new MedicalHistory()).toBeTruthy();
  });
});

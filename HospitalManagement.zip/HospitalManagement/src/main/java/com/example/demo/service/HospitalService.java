package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Hospital;
import com.example.demo.repo.HospitalRepository;

@Service
public class HospitalService {

    @Autowired
    private HospitalRepository hospitalRepository;

    public Hospital addHospital(Hospital hospital) {
        return hospitalRepository.save(hospital);
    }

    public List<Hospital> showByCity(String cityName) {
        if ("All".equalsIgnoreCase(cityName)) {
            List<Hospital> allHospitals = hospitalRepository.findAll();
            if (allHospitals.isEmpty()) {
                throw new ResourceNotFoundException("No hospitals available in the database.");
            }
            return allHospitals;
        }

        List<Hospital> list = hospitalRepository.findByCityName(cityName);
        if (list.isEmpty()) {
            throw new ResourceNotFoundException("No hospitals found in city: " + cityName);
        }
        return list;
    }


    public List<Hospital> showByCityAndLocation(String cityName, String locationArea) {
        List<Hospital> list = hospitalRepository.findByCityNameAndLocationArea(cityName, locationArea);
        if (list.isEmpty()) {
            throw new ResourceNotFoundException("No hospitals found in " + cityName + ", " + locationArea);
        }
        return list;
    }
    public Hospital updateHospital(int id, Hospital updatedData) {
        Hospital existing = hospitalRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Hospital not found with ID: " + id));

        existing.setHospitalName(updatedData.getHospitalName());
        existing.setCityName(updatedData.getCityName());
        existing.setLocationArea(updatedData.getLocationArea());
        existing.setContactNumber(updatedData.getContactNumber());
        existing.setRegisteredOn(updatedData.getRegisteredOn());

        return hospitalRepository.save(existing);
    }

    public void deleteHospital(int id) {
        Hospital hospital = hospitalRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Hospital not found with ID: " + id));
        hospitalRepository.delete(hospital);
    }

    
}

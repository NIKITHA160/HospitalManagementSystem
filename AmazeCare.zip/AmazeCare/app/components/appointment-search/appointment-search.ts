import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Appointment, AppointmentStatus } from '../../model/appointment';
import { DoctorService } from '../../service/doctor-service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-appointment-search',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule],
  templateUrl: './appointment-search.html',
  styleUrls: ['./appointment-search.css']
})
export class AppointmentSearchComponent {
  searchForm: FormGroup;
  appointments: Appointment[] = [];
  searched = false;

  AppointmentStatus = AppointmentStatus;
  statusKeys: string[] = Object.keys(AppointmentStatus);

  constructor(private fb: FormBuilder, private doctorService: DoctorService) {
    this.searchForm = this.fb.group({
      appointmentId: [''],
      patientId: [''],
      doctorId: [''],
      natureOfVisit: [''],
      symptoms: [''],
      status: ['']
    });
  }

  getStatusLabel(key: string): string {
    return AppointmentStatus[key as keyof typeof AppointmentStatus];
  }

  onSearch(): void {
    const raw: any = this.searchForm.value;

   
    const criteria: any = {};
    for (const key of Object.keys(raw)) {
      if (raw[key] !== '') {
        criteria[key] = raw[key];
      }
    }

    this.searched = true;

    this.doctorService.searchAppointments(criteria).subscribe({
      next: (data: Appointment[]) => {
        this.appointments = data;
      },
      error: (err) => {
        console.error('Search failed', err);
        this.appointments = [];
      }
    });
  }
}


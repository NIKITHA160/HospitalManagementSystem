import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Hospital } from '../../model/hospital';
import { Doctor } from '../../model/doctor';

@Component({
  selector: 'app-patient-view-hospitals',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule
  ],
  templateUrl: './patient-view-hospitals.html',
  styleUrl: './patient-view-hospitals.css'
})
export class PatientViewHospitalsComponent implements OnInit, AfterViewInit {

  hospitals: Hospital[] = [];
  doctors: Doctor[] = [];
  showDoctorSection = false;
  selectedHospitalName = '';
  dataSource = new MatTableDataSource<Hospital>([]);
  displayedColumns: string[] = ['hospitalName', 'cityName', 'locationArea', 'contactNumber', 'actions'];
  errorMessage = '';

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.dataSource.filterPredicate = (data: Hospital, filter: string) => {
      const combined = `${data.hospitalName} ${data.cityName} ${data.locationArea}`.toLowerCase();
      return combined.includes(filter);
    };
    this.loadHospitals();
  }

  ngAfterViewInit(): void {
    this.dataSource.paginator = this.paginator;
  }

  private getHeaders(): HttpHeaders {
    const token = localStorage.getItem('jwt');
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    });
  }

  loadHospitals(): void {
    this.http.get<Hospital[]>('http://localhost:8080/showByCity/All', {
      headers: this.getHeaders()
    }).subscribe({
      next: (data) => {
        this.hospitals = data;
        this.dataSource.data = this.hospitals;
      },
      error: (err) => {
        this.errorMessage = 'Failed to load hospitals.';
        console.error(err);
      }
    });
  }

  applyFilter(event: Event): void {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  getDoctorsByHospital(hospitalId: number, hospitalName: string): void {
    this.http.get<Doctor[]>(`http://localhost:8080/showDoctorByHospital/${hospitalId}`, {
      headers: this.getHeaders()
    }).subscribe({
      next: (data) => {
        this.doctors = data;
        this.selectedHospitalName = hospitalName;
        this.showDoctorSection = true;
      },
      error: (err) => {
        this.errorMessage = 'Failed to load doctors.';
        this.showDoctorSection = false;
        console.error(err);
      }
    });
  }
}


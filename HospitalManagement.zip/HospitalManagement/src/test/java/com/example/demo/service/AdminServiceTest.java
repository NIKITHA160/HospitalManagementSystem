package com.example.demo.service;

import com.example.demo.model.Admin;
import com.example.demo.repo.AdminRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class AdminServiceTest {

    @Mock
    private AdminRepository adminRepository;

    @InjectMocks
    private AdminService adminService;

    private Admin mockAdmin;

    @Before
    public void setUp() {
        mockAdmin = new Admin();
        mockAdmin.setAdminId(1);
        mockAdmin.setFullName("John Doe");
        mockAdmin.setEmailAddress("admin@example.com");
        mockAdmin.setLoginPassword("password");
        mockAdmin.setContactNumber("1234567890");
        mockAdmin.setRegisteredOn(new Timestamp(System.currentTimeMillis()));
    }

    @Test
    public void testAddAdmin() {
        when(adminRepository.save(mockAdmin)).thenReturn(mockAdmin);
        Admin result = adminService.addAdmin(mockAdmin);
        assertNotNull(result);
        assertEquals("John Doe", result.getFullName());
    }

    @Test
    public void testGetAllAdmins() {
        when(adminRepository.findAll()).thenReturn(Arrays.asList(mockAdmin));
        List<Admin> admins = adminService.getAllAdmins();
        assertEquals(1, admins.size());
    }

    @Test
    public void testGetAdminById() {
        when(adminRepository.findById(1)).thenReturn(Optional.of(mockAdmin));
        Optional<Admin> result = adminService.getAdminById(1);
        assertTrue(result.isPresent());
        assertEquals("John Doe", result.get().getFullName());
    }

    @Test
    public void testUpdateAdmin() {
        when(adminRepository.findById(1)).thenReturn(Optional.of(mockAdmin));
        when(adminRepository.save(any(Admin.class))).thenReturn(mockAdmin);

        Admin updated = new Admin();
        updated.setFullName("Updated Name");
        updated.setEmailAddress("updated@example.com");
        updated.setLoginPassword("updated123");
        updated.setContactNumber("9876543210");
        updated.setRegisteredOn(mockAdmin.getRegisteredOn());

        Admin result = adminService.updateAdmin(1, updated);
        assertEquals("Updated Name", result.getFullName());
    }

    @Test
    public void testDeleteAdminById() {
        adminService.deleteAdminById(1);
        verify(adminRepository, times(1)).deleteById(1);
    }
}

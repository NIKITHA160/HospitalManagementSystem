import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AdminService } from '../../service/admin-service';
import { Doctor } from '../../model/doctor';

@Component({
  selector: 'app-view-doctors',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './view-doctors.html',
  styleUrls: ['./view-doctors.css']
})
export class ViewDoctorsComponent implements OnInit {
  doctors: Doctor[] = [];
  errorMessage: string = '';

  constructor(private adminService: AdminService) {}

  ngOnInit(): void {
    this.loadDoctors();
  }

  loadDoctors(): void {
    this.adminService.getAllDoctors().subscribe({
      next: (data) => {
        this.doctors = data;
      },
      error: (err) => {
        this.errorMessage = 'Failed to load doctors';
        console.error(err);
      }
    });
  }
}

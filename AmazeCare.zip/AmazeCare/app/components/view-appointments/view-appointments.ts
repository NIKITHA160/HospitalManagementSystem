import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminService } from '../../service/admin-service';
import { Appointment, AppointmentStatus } from '../../model/appointment';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-view-appointments',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './view-appointments.html',
  styleUrls: ['./view-appointments.css']
})
export class ViewAppointmentsComponent implements OnInit {
  appointments: Appointment[] = [];
  error: string = '';
  success: string = '';

  constructor(private adminService: AdminService, private router: Router) {}

  ngOnInit(): void {
    this.fetchAppointments();
  }

  fetchAppointments(): void {
    this.adminService.getAllAppointments().subscribe({
      next: (data) => {
        this.appointments = data;
        this.error = '';
      },
      error: (err) => {
        console.error(err);
        this.error = 'Failed to load appointments.';
        this.appointments = [];
      }
    });
  }

  cancelAppointment(id: number): void {
  const appointment = this.appointments.find(a => a.appointmentId === id);
  if (appointment) {
    appointment.status = AppointmentStatus.cancelled; 
  }

  this.adminService.cancelAppointment(id).subscribe({
    next: () => {
      setTimeout(() => {
        this.router.navigate(['/active-appointments']);
      }, 300);
    },
    error: (err) => {
      console.error(err);
      
    }
  });
}

}

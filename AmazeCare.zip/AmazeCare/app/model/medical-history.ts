export class MedicalHistory {
  recordId: number;
  patientId: number;
  appointmentId: number;
  prescriptionId: number;
  diagnosis: string;
}

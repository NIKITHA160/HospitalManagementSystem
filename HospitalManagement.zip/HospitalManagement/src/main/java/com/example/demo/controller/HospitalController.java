package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.Hospital;
import com.example.demo.service.HospitalService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class HospitalController {

    @Autowired
    private HospitalService hospitalService;

    @PostMapping("/addHospital")
    public Hospital addHospital(@RequestBody Hospital hospital) {
        return hospitalService.addHospital(hospital);
    }

    @GetMapping("/showByCity/{cityName}")
    public ResponseEntity<List<Hospital>> showByCity(@PathVariable String cityName) {
        List<Hospital> hospitals = hospitalService.showByCity(cityName);
        if (hospitals.isEmpty()) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.ok(hospitals);
        }
    }

    @GetMapping("/showByCityAndLocation/{cityName}/{locationArea}")
    public ResponseEntity<List<Hospital>> showByCityAndLocation(@PathVariable String cityName, @PathVariable String locationArea) {
        List<Hospital> hospitals = hospitalService.showByCityAndLocation(cityName, locationArea);
        if (hospitals.isEmpty()) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.ok(hospitals);
        }
    }
    @PutMapping("/updateHospital/{id}")
    public ResponseEntity<Hospital> updateHospital(@PathVariable int id, @RequestBody Hospital hospital) {
        Hospital updatedHospital = hospitalService.updateHospital(id, hospital);
        return ResponseEntity.ok(updatedHospital);
    }

    // ✅ Delete hospital by ID
    @DeleteMapping("/deleteHospital/{id}")
    public ResponseEntity<Void> deleteHospital(@PathVariable int id) {
        hospitalService.deleteHospital(id);
        return ResponseEntity.noContent().build();
    }

}


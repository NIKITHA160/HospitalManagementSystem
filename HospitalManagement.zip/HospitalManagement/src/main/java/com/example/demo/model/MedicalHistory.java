package com.example.demo.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "medical_records")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MedicalHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int recordId;

    @Column(name = "patient_id")
    private Integer patientId;

    @Column(name = "appointment_id")
    private Integer appointmentId;

    @Column(name = "prescription_id")
    private Integer prescriptionId;

    private String diagnosis;

	public int getRecordId() {
		return recordId;
	}

	public Integer getPatientId() {
		return patientId;
	}

	public Integer getAppointmentId() {
		return appointmentId;
	}

	public Integer getPrescriptionId() {
		return prescriptionId;
	}

	public String getDiagnosis() {
		return diagnosis;
	}

	public void setRecordId(int recordId) {
		this.recordId = recordId;
	}

	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}

	public void setAppointmentId(Integer appointmentId) {
		this.appointmentId = appointmentId;
	}

	public void setPrescriptionId(Integer prescriptionId) {
		this.prescriptionId = prescriptionId;
	}

	public void setDiagnosis(String diagnosis) {
		this.diagnosis = diagnosis;
	}
}

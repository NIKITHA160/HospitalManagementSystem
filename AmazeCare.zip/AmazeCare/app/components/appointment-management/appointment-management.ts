import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { DoctorService } from '../../service/doctor-service';
import { Appointment, AppointmentStatus } from '../../model/appointment';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSort, MatSortModule } from '@angular/material/sort';

@Component({
  selector: 'app-appointment-management',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule
  ],
  templateUrl: './appointment-management.html',
  styleUrls: ['./appointment-management.css']
})
export class AppointmentManagementComponent implements OnInit, AfterViewInit {
  dataSource = new MatTableDataSource<Appointment>([]);
  displayedColumns: string[] = [
    'appointmentId',
    'patientId',
    'doctorId',
    'preferredDatetime',
    'symptoms',
    'natureOfVisit',
    'status',
    'actions'
  ];
  AppointmentStatus = AppointmentStatus;
  error: string = '';

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private doctorService: DoctorService, private router: Router) {}

  ngOnInit(): void {
    this.dataSource.filterPredicate = (data: Appointment, filter: string) => {
      const combined = `${data.appointmentId} ${data.patientId} ${data.doctorId} ${data.symptoms} ${data.natureOfVisit} ${data.status}`.toLowerCase();
      return combined.includes(filter.trim().toLowerCase());
    };

    this.fetchAllAppointments();
  }

  ngAfterViewInit(): void {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  fetchAllAppointments(): void {
    this.doctorService.getAllAppointments().subscribe({
      next: (data) => {
        this.dataSource.data = data; // ✅ do not reassign dataSource
        this.error = '';
      },
      error: (err) => {
        console.error(err);
        this.error = 'Failed to load appointments.';
        this.dataSource.data = [];
      }
    });
  }

  applyFilter(event: Event): void {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  cancelAppointment(id: number): void {
    this.doctorService.getAppointmentById(id).subscribe({
      next: (appointment) => {
        appointment.status = AppointmentStatus.cancelled;
        this.doctorService.updateAppointment(id, appointment).subscribe({
          next: () => this.fetchAllAppointments(),
          error: () => this.error = 'Failed to cancel appointment.'
        });
      },
      error: () => this.error = 'Appointment not found.'
    });
  }

  confirmAppointment(id: number): void {
    this.doctorService.getAppointmentById(id).subscribe({
      next: (appointment) => {
        appointment.status = AppointmentStatus.confirmed;
        this.doctorService.updateAppointment(id, appointment).subscribe({
          next: () => this.fetchAllAppointments(),
          error: () => this.error = 'Failed to confirm appointment.'
        });
      },
      error: () => this.error = 'Appointment not found.'
    });
  }

  updateAppointment(id: number): void {
    this.router.navigate(['/update-appointment', id]);
  }

  getStatusLabel(status: AppointmentStatus): string {
    return status.charAt(0).toUpperCase() + status.slice(1);
  }
}

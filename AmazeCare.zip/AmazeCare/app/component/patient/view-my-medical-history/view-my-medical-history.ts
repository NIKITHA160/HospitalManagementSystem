import { Component, OnInit } from '@angular/core';
import { PatientService } from '../../../service/patient-service';
import { MedicalHistory } from '../../../model/medical-history';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-view-my-medical-history',
  imports: [CommonModule,RouterModule,FormsModule,ReactiveFormsModule],
  templateUrl: './view-my-medical-history.html',
  styleUrl: './view-my-medical-history.css'
})
export class ViewMyMedicalHistoryComponent implements OnInit {
  medicalHistoryList: MedicalHistory[] = [];
  errorMessage: string = '';

  constructor(private patientService: PatientService) {}

  ngOnInit(): void {
    this.loadMedicalHistory();
  }

  loadMedicalHistory(): void {
    this.patientService.getMyMedicalHistory().subscribe({
      next: (data) => {
        this.medicalHistoryList = data;
        this.errorMessage = '';
      },
      error: (err) => {
        this.errorMessage = 'No medical history found or failed to load.';
        console.error(err);
      }
    });
  }
}

package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.Doctor;
import com.example.demo.service.DoctorService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class DoctorController {

    @Autowired
    private DoctorService doctorService;

    @PostMapping("/addDoctor")
    public Doctor addDoctor(@RequestBody Doctor doctor) {
        return doctorService.addDoctor(doctor);
    }

    @GetMapping("/showDoctor")
    public ResponseEntity<List<Doctor>> showAllDoctors() {
        List<Doctor> doctors = doctorService.showAllDoctors();
        if (doctors.isEmpty()) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.ok(doctors);
        }
    }

    @GetMapping("/showDoctorByDepartment/{department}")
    public ResponseEntity<List<Doctor>> showByDepartment(@PathVariable String department) {
        List<Doctor> doctors = doctorService.showByDepartment(department);
        if (doctors.isEmpty()) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.ok(doctors);
        }
    }

    @GetMapping("/searchDoctor/{name}")
    public ResponseEntity<List<Doctor>> searchByName(@PathVariable String name) {
        List<Doctor> doctors = doctorService.searchByName(name);
        if (doctors.isEmpty()) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.ok(doctors);
        }
    }
    @GetMapping("/showDoctorByHospital/{hospitalId}")
    public ResponseEntity<List<Doctor>> getDoctorsByHospital(@PathVariable Long hospitalId) {
        List<Doctor> doctors = doctorService.getDoctorsByHospital(hospitalId);
        if (doctors.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(doctors);
    }
    @PutMapping("/auth/doctor/update/{id}")
    public ResponseEntity<Doctor> updateDoctor(@PathVariable int id, @RequestBody Doctor doctor) {
        Doctor updated = doctorService.updateDoctor(id, doctor);
        return ResponseEntity.ok(updated);
    }
    @DeleteMapping("/auth/doctor/delete/{id}")
    public ResponseEntity<Void> deleteDoctor(@PathVariable int id) {
        doctorService.deleteDoctorById(id);
        return ResponseEntity.ok().build();
    }

    


}



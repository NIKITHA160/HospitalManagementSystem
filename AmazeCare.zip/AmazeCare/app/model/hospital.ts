export class Hospital {
  hospitalId: number;
  hospitalName: string;
  cityName: string;
  locationArea: string;
  contactNumber: string;
  registeredOn: Date;
}

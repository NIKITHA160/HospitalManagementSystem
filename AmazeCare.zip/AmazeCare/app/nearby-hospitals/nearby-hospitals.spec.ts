import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NearbyHospitals } from './nearby-hospitals';

describe('NearbyHospitals', () => {
  let component: NearbyHospitals;
  let fixture: ComponentFixture<NearbyHospitals>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NearbyHospitals]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NearbyHospitals);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

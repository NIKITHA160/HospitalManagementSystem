import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { PatientService } from '../../../service/patient-service';
import { Patient } from '../../../model/patient';

@Component({
  selector: 'app-update-patient',
  imports: [FormsModule,CommonModule,RouterModule,ReactiveFormsModule],
  templateUrl: './update-patient.html',
  styleUrl: './update-patient.css'
})
export class UpdatePatientComponent implements OnInit {
  updateForm!: FormGroup;
  patient!: Patient;

  constructor(
    private fb: FormBuilder,
    private patientService: PatientService
  ) {}

  ngOnInit(): void {
  const email = localStorage.getItem('userEmail');

  if (email) {
    this.patientService.getPatientByEmail(email).subscribe({
      next: (data) => {
        this.patient = data;
        this.updateForm = this.fb.group({
          fullName: [data.fullName, Validators.required],
          dateOfBirth: [data.dateOfBirth, Validators.required],
          gender: [data.gender, Validators.required],
          mobileNumber: [data.mobileNumber, [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
          emailAddress: [data.emailAddress, [Validators.required, Validators.email]],
          residentialAddress: [data.residentialAddress, Validators.required],
          loginPassword: ['']
        });
      },
      error: () => alert('Failed to load patient data')
    });
  } else {
    alert('No email found. Please log in again.');
  }
}


  onSubmit(): void {
  if (this.updateForm.valid && this.patient) {
    const formValue = this.updateForm.value;

    
    const updated: Patient = {
      ...this.patient,
      ...formValue,
      loginPassword: formValue.loginPassword ? formValue.loginPassword : this.patient.loginPassword
    };

    this.patientService.updatePatient(this.patient.patientId, updated).subscribe({
      next: () => alert('Patient updated successfully'),
      error: (err) => {
        console.error('Update failed:', err);  // 🔍 Debug log
        alert('Failed to update patient');
      }
    });
  }
}

}
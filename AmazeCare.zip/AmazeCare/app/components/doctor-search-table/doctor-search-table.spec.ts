import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DoctorSearchTable } from './doctor-search-table';

describe('DoctorSearchTable', () => {
  let component: DoctorSearchTable;
  let fixture: ComponentFixture<DoctorSearchTable>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DoctorSearchTable]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DoctorSearchTable);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

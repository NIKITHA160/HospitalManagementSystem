import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchMedicalRecord } from './search-medical-record';

describe('SearchMedicalRecord', () => {
  let component: SearchMedicalRecord;
  let fixture: ComponentFixture<SearchMedicalRecord>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SearchMedicalRecord]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SearchMedicalRecord);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

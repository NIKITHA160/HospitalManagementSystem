import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { AdminService } from '../../service/admin-service';
import { Hospital } from '../../model/hospital';

@Component({
  selector: 'app-add-hospital',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule, 
    RouterModule
  ],
  templateUrl: './add-hospital.html',
  styleUrls: ['./add-hospital.css']
})
export class AddHospitalComponent implements OnInit {
  hospitalForm!: FormGroup;
  message: string = ''; 

  constructor(
    private fb: FormBuilder,
    private adminService: AdminService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.hospitalForm = this.fb.group({
      hospitalName: ['', Validators.required],
      cityName: ['', Validators.required],
      locationArea: ['', Validators.required],
      contactNumber: ['', [Validators.required, Validators.pattern('[0-9]{10}')]],
      registeredOn: ['', Validators.required]
    });
  }

  onSubmit(): void {
    if (this.hospitalForm.valid) {
      const hospital: Hospital = this.hospitalForm.value;
      this.adminService.addHospital(hospital).subscribe({
        next: () => {
          this.message = 'Hospital added successfully!';
          this.router.navigate(['/view-hospitals']);
        },
        error: (err) => {
          console.error(err);
          this.message = 'Error adding hospital.';
        }
      });
    } else {
      this.message = 'Please fill out all required fields.';
    }
  }
}



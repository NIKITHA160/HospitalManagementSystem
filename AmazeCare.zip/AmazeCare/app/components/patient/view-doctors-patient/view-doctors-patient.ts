import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { Doctor } from '../../../model/doctor';
import { AdminService } from '../../../service/admin-service';

@Component({
  selector: 'app-view-doctors-patient',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './view-doctors-patient.html',
  styleUrls: ['./view-doctors-patient.css']
})
export class ViewDoctorsPatientComponent implements OnInit {
  doctors: Doctor[] = [];
  filteredDoctors: Doctor[] = [];
  searchTerm: string = '';
  errorMessage: string = '';

  constructor(private adminService: AdminService, private router: Router) {}

  ngOnInit(): void {
    this.adminService.getAllDoctors().subscribe({
      next: (data) => {
        this.doctors = data;
        this.filteredDoctors = data;
      },
      error: (err) => {
        this.errorMessage = 'Error fetching doctors.';
      }
    });
  }

  search(): void {
    const term = this.searchTerm.toLowerCase();
    this.filteredDoctors = this.doctors.filter(doc =>
      doc.fullName.toLowerCase().includes(term) ||
      doc.department.toLowerCase().includes(term)
    );
  }

  reset(): void {
    this.searchTerm = '';
    this.filteredDoctors = this.doctors;
  }

  bookAppointment(doctorId: number): void {
    this.router.navigate(['/book-appointment'], { queryParams: { doctorId } });
  }
}

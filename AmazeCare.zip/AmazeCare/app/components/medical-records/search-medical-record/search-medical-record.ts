import { Component } from '@angular/core';
import { MedicalHistory } from '../../../model/medical-history';
import { DoctorService } from '../../../service/doctor-service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-search-medical-record',
  imports: [FormsModule, CommonModule, RouterModule],
  templateUrl: './search-medical-record.html',
  styleUrl: './search-medical-record.css'
})
export class SearchMedicalRecordComponent {
  recordId = '';
  record?: MedicalHistory;
  searchAttempted = false;

  constructor(private doctorService: DoctorService) {}

  searchRecord() {
    this.searchAttempted = true;
    this.record = undefined;

    this.doctorService.getMedicalRecordById(+this.recordId).subscribe({
      next: data => this.record = data,
      error: () => this.record = undefined
    });
  }
}

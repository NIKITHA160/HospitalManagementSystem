import { Component, AfterViewInit } from '@angular/core';
import * as L from 'leaflet';

@Component({
  selector: 'app-nearby-hospitals',
  templateUrl: './nearby-hospitals.html',
  styleUrls: ['./nearby-hospitals.css']
})
export class NearbyHospitalsComponent implements AfterViewInit {
  private map: L.Map | undefined;

  ngAfterViewInit(): void {
    this.initMap();
  }

  private initMap(): void {
    this.map = L.map('map', {
      center: [17.385044, 78.486671], 
      zoom: 13
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(this.map);

    
    L.marker([17.387140, 78.491684]).addTo(this.map).bindPopup('Amaze Hospital');
    L.marker([17.380000, 78.480000]).addTo(this.map).bindPopup('City Care Clinic');
  }
}

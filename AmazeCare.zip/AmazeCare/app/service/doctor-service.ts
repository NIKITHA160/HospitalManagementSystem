import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Doctor } from '../model/doctor';
import { Appointment } from '../model/appointment';
import { MedicalHistory } from '../model/medical-history';

@Injectable({
  providedIn: 'root'
})
export class DoctorService {

  private baseUrl = 'http://localhost:8080';

  constructor(private http: HttpClient) {}

  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('jwt');
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
  }

  
  loginDoctor(data: { email: string, password: string }): Observable<any> {
    return this.http.post(`${this.baseUrl}/doctorLogin`, data);
  }

  
  showAllDoctors(): Observable<Doctor[]> {
    return this.http.get<Doctor[]>(`${this.baseUrl}/showDoctor`, { headers: this.getAuthHeaders() });
  }

  getDoctorsByDepartment(department: string): Observable<Doctor[]> {
    return this.http.get<Doctor[]>(`${this.baseUrl}/showDoctorByDepartment/${department}`, { headers: this.getAuthHeaders() });
  }

  searchDoctorsByName(name: string): Observable<Doctor[]> {
    return this.http.get<Doctor[]>(`${this.baseUrl}/searchDoctor/${name}`, { headers: this.getAuthHeaders() });
  }

  getDoctorProfile(): Observable<Doctor> {
    return this.http.get<Doctor>(`${this.baseUrl}/auth/doctor/profile`, { headers: this.getAuthHeaders() });
  }

  
  getAllAppointments(): Observable<Appointment[]> {
    return this.http.get<Appointment[]>(`${this.baseUrl}/showAppointments`, { headers: this.getAuthHeaders() });
  }

  getAppointmentById(id: number): Observable<Appointment> {
    return this.http.get<Appointment>(`${this.baseUrl}/appointment/${id}`, { headers: this.getAuthHeaders() });
  }

  searchAppointments(criteria: Appointment): Observable<Appointment[]> {
    return this.http.post<Appointment[]>(`${this.baseUrl}/searchAppointments`, criteria, { headers: this.getAuthHeaders() });
  }

  

  
  addMedicalRecord(record: MedicalHistory): Observable<MedicalHistory> {
    return this.http.post<MedicalHistory>(`${this.baseUrl}/addMedicalRecord`, record, { headers: this.getAuthHeaders() });
  }

  
  getMedicalHistoryByPatientId(patientId: number): Observable<MedicalHistory[]> {
    return this.http.get<MedicalHistory[]>(`${this.baseUrl}/medicalHistory/${patientId}`, { headers: this.getAuthHeaders() });
  }

  
  getMedicalRecordById(recordId: number): Observable<MedicalHistory> {
    return this.http.get<MedicalHistory>(`${this.baseUrl}/medicalRecord/${recordId}`, { headers: this.getAuthHeaders() });
  }

  
  updateMedicalRecord(recordId: number, updatedRecord: MedicalHistory): Observable<MedicalHistory> {
    return this.http.put<MedicalHistory>(`${this.baseUrl}/updateMedicalRecord/${recordId}`, updatedRecord, {
      headers: this.getAuthHeaders()
    });
  }

  
  deleteMedicalRecord(recordId: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/deleteMedicalRecord/${recordId}`, {
      headers: this.getAuthHeaders()
    });
  }
  updateAppointment(id: number, updatedAppointment: Appointment): Observable<Appointment> {
  return this.http.put<Appointment>(`${this.baseUrl}/updateAppointment/${id}`, updatedAppointment, {
    headers: this.getAuthHeaders()
  });
}
updateDoctorProfile(id: number, doctor: Doctor): Observable<Doctor> {
  return this.http.put<Doctor>(`${this.baseUrl}/auth/doctor/update/${id}`, doctor, {
    headers: this.getAuthHeaders()
  });
}


}



package com.example.demo.model;

public enum AppointmentStatus {
    pending,
    confirmed,
    cancelled,
    completed
}

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Admin } from '../model/admin';
import { Doctor } from '../model/doctor';
import { Hospital } from '../model/hospital';
import { Appointment } from '../model/appointment';
import { MedicalHistory } from '../model/medical-history';

@Injectable({ providedIn: 'root' })
export class AdminService {
  private baseUrl = 'http://localhost:8080';

  constructor(private http: HttpClient) {}

  private getHeaders(): HttpHeaders {
    const token = localStorage.getItem('jwt');
    return new HttpHeaders().set('Authorization', `Bearer ${token}`);
  }

  loginAdmin(data: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/admin/login`, data);
  }

  addAdmin(admin: Admin): Observable<Admin> {
    return this.http.post<Admin>(`${this.baseUrl}/addAdmin`, admin, { headers: this.getHeaders() });
  }

  getAllAdmins(): Observable<Admin[]> {
    return this.http.get<Admin[]>(`${this.baseUrl}/showAdmins`, { headers: this.getHeaders() });
  }

  getAdminById(id: number): Observable<Admin> {
    return this.http.get<Admin>(`${this.baseUrl}/admin/${id}`, { headers: this.getHeaders() });
  }

  updateAdmin(id: number, admin: Admin): Observable<Admin> {
    return this.http.put<Admin>(`${this.baseUrl}/updateAdmin/${id}`, admin, { headers: this.getHeaders() });
  }

  deleteAdmin(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/deleteAdmin/${id}`, { headers: this.getHeaders() });
  }

  getAdminProfile(): Observable<Admin> {
    return this.http.get<Admin>(`${this.baseUrl}/auth/admin/profile`, { headers: this.getHeaders() });
  }

  addDoctor(doctor: Doctor): Observable<Doctor> {
    return this.http.post<Doctor>(`${this.baseUrl}/addDoctor`, doctor, { headers: this.getHeaders() });
  }

  getAllDoctors(): Observable<Doctor[]> {
    return this.http.get<Doctor[]>(`${this.baseUrl}/showDoctor`, { headers: this.getHeaders() });
  }

  getDoctorsByDepartment(dept: string): Observable<Doctor[]> {
    return this.http.get<Doctor[]>(`${this.baseUrl}/showDoctorByDepartment/${dept}`, { headers: this.getHeaders() });
  }

  searchDoctorByName(name: string): Observable<Doctor[]> {
    return this.http.get<Doctor[]>(`${this.baseUrl}/searchDoctor/${name}`, { headers: this.getHeaders() });
  }
  updateDoctor(id: number, doctor: Doctor): Observable<Doctor> {
  return this.http.put<Doctor>(`${this.baseUrl}/auth/doctor/update/${id}`, doctor, { headers: this.getHeaders() });
}

deleteDoctor(id: number): Observable<void> {
  return this.http.delete<void>(`${this.baseUrl}/auth/doctor/delete/${id}`, { headers: this.getHeaders() });
}


  addHospital(hospital: Hospital): Observable<Hospital> {
  return this.http.post<Hospital>(`${this.baseUrl}/addHospital`, hospital, {
    headers: this.getHeaders()
  });
}


  getHospitalsByCity(city: string): Observable<Hospital[]> {
    return this.http.get<Hospital[]>(`${this.baseUrl}/showByCity/${city}`, { headers: this.getHeaders() });
  }

  getHospitalsByCityAndLocation(city: string, area: string): Observable<Hospital[]> {
    return this.http.get<Hospital[]>(`${this.baseUrl}/showByCityAndLocation/${city}/${area}`, { headers: this.getHeaders() });
  }

  addAppointment(appointment: Appointment): Observable<Appointment> {
    return this.http.post<Appointment>(`${this.baseUrl}/addAppointment`, appointment, { headers: this.getHeaders() });
  }

  updateAppointment(id: number, appointment: Appointment): Observable<Appointment> {
    return this.http.put<Appointment>(`${this.baseUrl}/updateAppointment/${id}`, appointment, { headers: this.getHeaders() });
  }

  cancelAppointment(id: number): Observable<any> {
    return this.http.put(`${this.baseUrl}/cancelAppointment/${id}`, {}, { headers: this.getHeaders() });
  }

  addMedicalRecord(record: MedicalHistory): Observable<MedicalHistory> {
    return this.http.post<MedicalHistory>(`${this.baseUrl}/addMedicalRecord`, record, { headers: this.getHeaders() });
  }

  getAllAppointments(): Observable<Appointment[]> {
    return this.http.get<Appointment[]>(`${this.baseUrl}/showAppointments`, { headers: this.getHeaders() });
  }

  getAppointmentById(id: number): Observable<Appointment> {
    return this.http.get<Appointment>(`${this.baseUrl}/appointment/${id}`, { headers: this.getHeaders() });
  }
  updateHospital(id: number, hospital: Hospital): Observable<Hospital> {
  return this.http.put<Hospital>(`${this.baseUrl}/updateHospital/${id}`, hospital, {
    headers: this.getHeaders(),
  });
}

deleteHospital(id: number): Observable<void> {
  return this.http.delete<void>(`${this.baseUrl}/deleteHospital/${id}`, {
    headers: this.getHeaders(),
  });
}

  

}

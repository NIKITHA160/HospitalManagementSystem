import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ActiveAppointments } from './active-appointments';

describe('ActiveAppointments', () => {
  let component: ActiveAppointments;
  let fixture: ComponentFixture<ActiveAppointments>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ActiveAppointments]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ActiveAppointments);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

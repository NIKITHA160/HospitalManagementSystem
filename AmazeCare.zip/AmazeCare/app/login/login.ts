import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { AuthRequest } from '../model/auth-request';
import { AuthService } from '../service/auth-service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './login.html',
  styleUrls: ['./login.css']
})
export class LoginComponent {
  email: string = '';
  password: string = '';
  jwt: string = '';
  authRequest: AuthRequest = new AuthRequest();
  errorMsg: string = '';
   showAbout: boolean = false;
   showNew: boolean = false; 
  constructor(private _authService: AuthService, private _router: Router) {}

  login() {
    this.authRequest.username = this.email;
    this.authRequest.password = this.password;

    this._authService.login(this.authRequest).subscribe({
      next: (token: string) => {
        localStorage.setItem('jwt', token);
        this.jwt = token;

        const role = this._authService.extractRoleFromToken(token);

        if (role === 'ROLE_ADMIN') {
          this._router.navigate(['/admin-dashboard']);
        } else if (role === 'ROLE_DOCTOR') {
          this._router.navigate(['/doctor-dashboard']);
        } else if (role === 'ROLE_USER') {
          localStorage.setItem('userEmail', this.email);
          this._router.navigate(['/patient-dashboard']);
        } else {
          this.errorMsg = 'Unknown role. Access denied.';
          localStorage.removeItem('jwt');
        }
      },
      error: () => {
        this.errorMsg = 'Invalid email or password!';
      }
    });
  }
  
}

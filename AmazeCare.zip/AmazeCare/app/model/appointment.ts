export enum AppointmentStatus {
  pending = 'pending',
  confirmed = 'confirmed',
  cancelled = 'cancelled',
  completed = 'completed'
}

export class Appointment {
  appointmentId: number;
  patientId: number;
  doctorId: number;
  preferredDatetime: Date;
  symptoms: string;
  natureOfVisit: string;
  status: AppointmentStatus;
}

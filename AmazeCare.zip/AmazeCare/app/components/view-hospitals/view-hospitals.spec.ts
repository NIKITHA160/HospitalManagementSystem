import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewHospitals } from './view-hospitals';

describe('ViewHospitals', () => {
  let component: ViewHospitals;
  let fixture: ComponentFixture<ViewHospitals>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ViewHospitals]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewHospitals);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

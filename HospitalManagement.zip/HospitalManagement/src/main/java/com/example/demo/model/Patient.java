package com.example.demo.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "patients")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Patient {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int patientId;

    private String fullName;

    public int getPatientId() {
		return patientId;
	}

	public String getFullName() {
		return fullName;
	}

	public java.sql.Date getDateOfBirth() {
		return dateOfBirth;
	}

	public String getGender() {
		return gender;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public String getLoginPassword() {
		return loginPassword;
	}

	public String getResidentialAddress() {
		return residentialAddress;
	}

	public java.sql.Timestamp getRegisteredOn() {
		return registeredOn;
	}

	public boolean isAdmitted() {
		return isAdmitted;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public void setDateOfBirth(java.sql.Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}

	public void setResidentialAddress(String residentialAddress) {
		this.residentialAddress = residentialAddress;
	}

	public void setRegisteredOn(java.sql.Timestamp registeredOn) {
		this.registeredOn = registeredOn;
	}

	public void setAdmitted(boolean isAdmitted) {
		this.isAdmitted = isAdmitted;
	}

	@Column(name = "date_of_birth")
    private java.sql.Date dateOfBirth;

    private String gender;

    private String mobileNumber;
    private String emailAddress;
    private String loginPassword;

    private String residentialAddress;

    @Column(name = "registered_on")
    private java.sql.Timestamp registeredOn;

    private boolean isAdmitted;
}

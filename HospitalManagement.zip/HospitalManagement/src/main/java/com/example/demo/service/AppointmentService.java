package com.example.demo.service;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Appointment;
import com.example.demo.model.AppointmentStatus;
import com.example.demo.repo.AppointmentRepository;

import java.util.List;
@Service
public class AppointmentService {

    @Autowired
    private AppointmentRepository appointmentRepository;

    public Appointment addAppointment(Appointment appointment) {
        appointment.setStatus(AppointmentStatus.pending);
        return appointmentRepository.save(appointment);
    }

    public Appointment updateAppointment(int id, Appointment updated) {
        Appointment appointment = appointmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Appointment not found with id: " + id));
        appointment.setPreferredDatetime(updated.getPreferredDatetime());
        appointment.setSymptoms(updated.getSymptoms());
        appointment.setNatureOfVisit(updated.getNatureOfVisit());
        appointment.setStatus(updated.getStatus());
        return appointmentRepository.save(appointment);
    }

    public String cancelAppointment(int id) {
        Appointment appointment = appointmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Appointment not found with id: " + id));
        appointment.setStatus(AppointmentStatus.cancelled);
        appointmentRepository.save(appointment);
        return "Appointment cancelled successfully.";
    }
    public List<Appointment> getAllAppointments() {
        return appointmentRepository.findAll();
    }
    public Appointment getAppointmentById(int id) {
        return appointmentRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Appointment not found with id: " + id));
    }
    public List<Appointment> searchAppointments(Appointment criteria) {
        List<Appointment> allAppointments = appointmentRepository.findAll();

        return allAppointments.stream()
            .filter(appt -> criteria.getAppointmentId() == 0 || appt.getAppointmentId() == criteria.getAppointmentId())
            .filter(appt -> criteria.getPatientId() == 0 || appt.getPatientId() == criteria.getPatientId())
            .filter(appt -> criteria.getDoctorId() == 0 || appt.getDoctorId() == criteria.getDoctorId())
            .filter(appt -> criteria.getPreferredDatetime() == null ||
            appt.getPreferredDatetime().toLocalDateTime().toLocalDate()
                .equals(criteria.getPreferredDatetime().toLocalDateTime().toLocalDate()))

            .filter(appt -> criteria.getSymptoms() == null || 
                            appt.getSymptoms().toLowerCase().contains(criteria.getSymptoms().toLowerCase()))
            .filter(appt -> criteria.getNatureOfVisit() == null || 
                            appt.getNatureOfVisit().toLowerCase().contains(criteria.getNatureOfVisit().toLowerCase()))
            .filter(appt -> criteria.getStatus() == null || appt.getStatus().equals(criteria.getStatus()))
            .toList();
    }


    public List<Appointment> getAppointmentsByPatientId(int patientId) {
        return appointmentRepository.findByPatientId(patientId);
    }

    public List<Appointment> getAppointmentsByPatient(int patientId) {
        return appointmentRepository.findByPatientId(patientId);
    }



}

package com.example.demo.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "appointment")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Appointment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int appointmentId;

    @Column(name = "patient_id")
    private int patientId;

    public int getAppointmentId() {
		return appointmentId;
	}

	public int getPatientId() {
		return patientId;
	}

	public int getDoctorId() {
		return doctorId;
	}

	public java.sql.Timestamp getPreferredDatetime() {
		return preferredDatetime;
	}

	public String getSymptoms() {
		return symptoms;
	}

	public String getNatureOfVisit() {
		return natureOfVisit;
	}

	public AppointmentStatus getStatus() {
		return status;
	}

	public void setAppointmentId(int appointmentId) {
		this.appointmentId = appointmentId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}

	public void setPreferredDatetime(java.sql.Timestamp preferredDatetime) {
		this.preferredDatetime = preferredDatetime;
	}

	public void setSymptoms(String symptoms) {
		this.symptoms = symptoms;
	}

	public void setNatureOfVisit(String natureOfVisit) {
		this.natureOfVisit = natureOfVisit;
	}

	public void setStatus(AppointmentStatus status) {
		this.status = status;
	}

	@Column(name = "doctor_id")
    private int doctorId;

    @Column(name = "preferred_datetime")
    private java.sql.Timestamp preferredDatetime;

    private String symptoms;

    @Column(name = "nature_of_visit")
    private String natureOfVisit;

    @Enumerated(EnumType.STRING)
    private AppointmentStatus status = AppointmentStatus.pending;
}


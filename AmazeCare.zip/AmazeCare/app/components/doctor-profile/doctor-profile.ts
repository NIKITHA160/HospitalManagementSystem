import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { DoctorService } from '../../service/doctor-service';
import { Doctor } from '../../model/doctor';

@Component({
  selector: 'app-doctor-profile',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterModule],
  templateUrl: './doctor-profile.html',
  styleUrl: './doctor-profile.css'
})
export class DoctorProfileComponent implements OnInit {
  doctorForm!: FormGroup;
  doctorId!: number;
  successMessage = '';
  errorMessage = '';

  constructor(private fb: FormBuilder, private doctorService: DoctorService) {}

  ngOnInit(): void {
    // 🔐 Retrieve email from localStorage after login
    const email = localStorage.getItem('email');
    if (!email) {
      this.errorMessage = '❌ Doctor email not found. Please log in again.';
      return;
    }

    // 🔧 Build the form
    this.doctorForm = this.fb.group({
      fullName: ['', Validators.required],
      emailAddress: [{ value: '', disabled: true }],  // Display-only field
      mobileNumber: ['', Validators.required],
      department: ['', Validators.required],
      designation: ['', Validators.required],
      qualification: ['', Validators.required],
      yearsOfExperience: ['', Validators.required],
      hospitalId: ['', Validators.required],
      loginPassword: ['']  // Optional password change
    });

    // 🔄 Load doctor profile by email
    this.doctorService.getDoctorProfile().subscribe({
      next: (doctor: Doctor) => {
        this.doctorId = doctor.doctorId;
        this.doctorForm.patchValue(doctor);
      },
      error: () => {
        this.errorMessage = '❌ Failed to load doctor profile.';
      }
    });
  }

  onSubmit(): void {
    if (this.doctorForm.invalid) {
      this.errorMessage = '❌ Please fill in all required fields.';
      return;
    }

    const updatedDoctor: Doctor = {
      ...this.doctorForm.getRawValue(), // includes disabled email field
      doctorId: this.doctorId,
      registeredOn: new Date(),  // Optional: backend may override
      loginPassword: this.doctorForm.value.loginPassword  // Optional password update
    };

    this.doctorService.updateDoctorProfile(this.doctorId, updatedDoctor).subscribe({
      next: () => {
        this.successMessage = '✅ Profile updated successfully!';
        this.errorMessage = '';
        this.doctorForm.patchValue({ loginPassword: '' });  // Clear password field
      },
      error: () => {
        this.successMessage = '';
        this.errorMessage = '❌ Failed to update profile.';
      }
    });
  }
}

import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DoctorService } from '../../service/doctor-service';
import { Doctor } from '../../model/doctor';

@Component({
  selector: 'app-doctor-search',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './doctor-search.html',
  styleUrls: ['./doctor-search.css']
})
export class DoctorSearchComponent implements OnInit {
  doctors: Doctor[] = [];
  name: string = '';
  department: string = '';
  doctorId: number | null = null;
  errorMessage = '';
  showResults = false;

  constructor(private doctorService: DoctorService) {}

  ngOnInit(): void {}

  searchByName(): void {
    if (!this.name.trim()) {
      this.errorMessage = 'Please enter a doctor name.';
      return;
    }
    this.doctorService.searchDoctorsByName(this.name).subscribe({
      next: (data) => {
        this.doctors = data;
        this.errorMessage = '';
        this.showResults = true;
      },
      error: () => {
        this.errorMessage = 'No doctors found.';
        this.doctors = [];
        this.showResults = false;
      }
    });
  }

  searchByDepartment(): void {
    if (!this.department.trim()) {
      this.errorMessage = 'Please enter a department.';
      return;
    }
    this.doctorService.getDoctorsByDepartment(this.department).subscribe({
      next: (data) => {
        this.doctors = data;
        this.errorMessage = '';
        this.showResults = true;
      },
      error: () => {
        this.errorMessage = 'No doctors found.';
        this.doctors = [];
        this.showResults = false;
      }
    });
  }

  searchById(): void {
    if (!this.doctorId) {
      this.errorMessage = 'Please enter a valid doctor ID.';
      return;
    }
    this.doctorService.showAllDoctors().subscribe({
      next: (allDoctors) => {
        const match = allDoctors.find(doc => doc.doctorId === this.doctorId);
        if (match) {
          this.doctors = [match];
          this.errorMessage = '';
          this.showResults = true;
        } else {
          this.doctors = [];
          this.errorMessage = 'Doctor not found.';
          this.showResults = false;
        }
      },
      error: () => {
        this.errorMessage = 'Error fetching doctors.';
        this.doctors = [];
        this.showResults = false;
      }
    });
  }
}

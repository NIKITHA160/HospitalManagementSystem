export class AuthRequest {
  username: string;  // This will carry email
  password: string;
}

package com.example.demo.service;

import com.example.demo.model.Doctor;
import com.example.demo.model.UserData;
import com.example.demo.repo.DoctorRepository;
import com.example.demo.repo.UserDataRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class DoctorServiceTest {

    @Mock private DoctorRepository doctorRepository;
    @Mock private UserDataRepository userDataRepository;
    @Mock private BCryptPasswordEncoder passwordEncoder;

    @InjectMocks private DoctorService doctorService;

    private Doctor doctor;

    @Before
    public void setUp() {
        doctor = new Doctor();
        doctor.setDoctorId(1);
        doctor.setFullName("Dr. Smith");
        doctor.setEmailAddress("dr.smith@example.com");
        doctor.setLoginPassword("plainpass");
        doctor.setHospitalId(1);
    }

    @Test
    public void testAddDoctor() {
        when(passwordEncoder.encode(anyString())).thenReturn("encrypted");
        when(doctorRepository.save(any(Doctor.class))).thenReturn(doctor);

        Doctor result = doctorService.addDoctor(doctor);
        assertNotNull(result);
        verify(userDataRepository).save(any(UserData.class));
    }

    @Test
    public void testShowAllDoctors() {
        when(doctorRepository.findAll()).thenReturn(Arrays.asList(doctor));
        List<Doctor> result = doctorService.showAllDoctors();
        assertEquals(1, result.size());
    }
}

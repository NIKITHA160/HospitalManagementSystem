package com.example.demo.service;

import com.example.demo.model.Patient;
import com.example.demo.repo.PatientRepository;
import com.example.demo.exception.ResourceNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;
@Service
public class PatientService {

    @Autowired
    private PatientRepository patientRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public Patient addPatient(Patient patient) {
        patient.setLoginPassword(passwordEncoder.encode(patient.getLoginPassword()));
        patient.setRegisteredOn(new Timestamp(System.currentTimeMillis()));
        patient.setAdmitted(false);
        return patientRepository.save(patient);
    }

    public Patient updatePatient(int id, Patient updatedPatient) {
        Patient existing = patientRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with ID: " + id));

        existing.setFullName(updatedPatient.getFullName());
        existing.setDateOfBirth(updatedPatient.getDateOfBirth());
        existing.setGender(updatedPatient.getGender());
        existing.setMobileNumber(updatedPatient.getMobileNumber());
        existing.setEmailAddress(updatedPatient.getEmailAddress());
        existing.setResidentialAddress(updatedPatient.getResidentialAddress());

        if (updatedPatient.getLoginPassword() != null && !updatedPatient.getLoginPassword().isEmpty()) {
            existing.setLoginPassword(passwordEncoder.encode(updatedPatient.getLoginPassword()));
        }

        return patientRepository.save(existing);
    }

    public boolean authenticate(String email, String rawPassword) {
        Optional<Patient> patientOpt = patientRepository.findByEmailAddress(email);
        return patientOpt.isPresent() &&
                passwordEncoder.matches(rawPassword, patientOpt.get().getLoginPassword());
    }

    public Patient getPatientByEmailAddress(String emailAddress) {
        return patientRepository.findByEmailAddress(emailAddress)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with email: " + emailAddress));
    }

}

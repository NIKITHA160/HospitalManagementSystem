package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import com.example.demo.config.JwtService;
import com.example.demo.model.MedicalHistory;
import com.example.demo.model.Patient;
import com.example.demo.repo.PatientRepository;
import com.example.demo.service.MedicalHistoryService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class MedicalHistoryController {

    @Autowired
    private MedicalHistoryService medicalHistoryService;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private PatientRepository patientRepository;

    
    @PostMapping("/addMedicalRecord")
    public MedicalHistory addMedicalRecord(@RequestBody MedicalHistory record) {
        return medicalHistoryService.addMedicalRecord(record);
    }

    
    @GetMapping("/medicalHistory/{patientId}")
    public ResponseEntity<List<MedicalHistory>> getMedicalHistoryByPatient(@PathVariable int patientId) {
        List<MedicalHistory> records = medicalHistoryService.getMedicalHistoryByPatient(patientId);
        return records.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(records);
    }

    
    @PutMapping("/updateMedicalRecord/{id}")
    public ResponseEntity<MedicalHistory> updateMedicalRecord(@PathVariable int id, @RequestBody MedicalHistory record) {
        MedicalHistory updated = medicalHistoryService.updateMedicalRecord(id, record);
        return updated != null ? ResponseEntity.ok(updated) : ResponseEntity.notFound().build();
    }

    
    @DeleteMapping("/deleteMedicalRecord/{id}")
    public ResponseEntity<Void> deleteMedicalRecord(@PathVariable int id) {
        boolean deleted = medicalHistoryService.deleteMedicalRecord(id);
        return deleted ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }

    
    @GetMapping("/medicalRecord/{id}")
    public ResponseEntity<MedicalHistory> getMedicalRecordById(@PathVariable int id) {
        MedicalHistory record = medicalHistoryService.getMedicalRecordById(id);
        return record != null ? ResponseEntity.ok(record) : ResponseEntity.notFound().build();
    }

    
    @GetMapping("/myMedicalHistory")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public ResponseEntity<List<MedicalHistory>> getMyMedicalHistory(@RequestHeader("Authorization") String authHeader) {
        try {
            
            String token = authHeader.substring(7); 
            String email = jwtService.extractUsername(token);

            // Find patient by email
            Optional<Patient> optionalPatient = patientRepository.findByEmailAddress(email);
            if (optionalPatient.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
            }

            Patient patient = optionalPatient.get();
            List<MedicalHistory> records = medicalHistoryService.getMedicalHistoryByPatient(patient.getPatientId());

            return records.isEmpty() ? ResponseEntity.noContent().build() : ResponseEntity.ok(records);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }
}


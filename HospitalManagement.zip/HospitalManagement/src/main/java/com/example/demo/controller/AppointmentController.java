package com.example.demo.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.demo.model.Appointment;
import com.example.demo.service.AppointmentService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class AppointmentController {

	@Autowired
	private AppointmentService appointmentService;

	@PostMapping("/addAppointment")
	public Appointment addAppointment(@RequestBody Appointment appointment) {
		return appointmentService.addAppointment(appointment);
	}

	@PutMapping("/updateAppointment/{id}")
	public ResponseEntity<Appointment> updateAppointment(@PathVariable int id, @RequestBody Appointment appointment) {
		Appointment updated = appointmentService.updateAppointment(id, appointment);
		if (updated != null) {
			return ResponseEntity.ok(updated);
		} else {
			return ResponseEntity.notFound().build();
		}
	}

	@PutMapping("/cancelAppointment/{id}")
	public ResponseEntity<String> cancelAppointment(@PathVariable int id) {
		String result = appointmentService.cancelAppointment(id);
		if ("Cancelled".equalsIgnoreCase(result)) {
			return ResponseEntity.ok(result);
		} else {
			return ResponseEntity.status(400).body(result);
		}
	}
	@GetMapping("/showAppointments")
	public List<Appointment> getAllAppointments() {
	    return appointmentService.getAllAppointments();
	}
	@GetMapping("/appointment/{id}")
	public ResponseEntity<Appointment> getAppointmentById(@PathVariable int id) {
	    Appointment appt = appointmentService.getAppointmentById(id);
	    return ResponseEntity.ok(appt);
	}
	@PostMapping("/searchAppointments")
	public ResponseEntity<List<Appointment>> searchAppointments(@RequestBody Appointment criteria) {
	    List<Appointment> results = appointmentService.searchAppointments(criteria);
	    if (results.isEmpty()) {
	        return ResponseEntity.noContent().build();
	    } else {
	        return ResponseEntity.ok(results);
	    }
	}
	@GetMapping("/appointment/patient/{id}")
	public List<Appointment> getAppointmentsByPatient(@PathVariable int id) {
	    return appointmentService.getAppointmentsByPatientId(id);
	}
	




	
}

import { Component, OnInit } from '@angular/core';
import { Patient } from '../../../model/patient';
import { PatientService } from '../../../service/patient-service';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-view-patient-profile',
  imports: [CommonModule,FormsModule,RouterModule,ReactiveFormsModule],
  templateUrl: './view-patient-profile.html',
  styleUrl: './view-patient-profile.css'
})
export class ViewPatientProfileComponent implements OnInit {
  patientForm!: FormGroup;
  patientId!: number;
  successMessage = '';
  errorMessage = '';

  constructor(
    private fb: FormBuilder,
    private patientService: PatientService
  ) {}

  ngOnInit(): void {
 this.patientForm = this.fb.group({
  fullName: ['', Validators.required],
  dateOfBirth: ['', Validators.required],
  gender: ['', Validators.required],
  mobileNumber: ['', Validators.required],
  emailAddress: [{ value: '', disabled: true }],  // ✅ Properly disabled via FormControl config
  loginPassword: [''],
  residentialAddress: ['', Validators.required]
});

    const email = localStorage.getItem('userEmail');
    if (email) {
      this.patientService.getPatientByEmail(email).subscribe({
        next: (patient: Patient) => {
          this.patientId = patient.patientId;
          this.patientForm.patchValue(patient);
        },
        error: () => {
          this.errorMessage = '❌ Failed to load patient data.';
        }
      });
    }
  }

  onSubmit(): void {
    if (this.patientForm.invalid) {
      this.errorMessage = '❌ Please fill in all required fields.';
      return;
    }

    const updatedPatient: Patient = {
      ...this.patientForm.getRawValue(), // includes disabled fields like email
      patientId: this.patientId,
      registeredOn: new Date(),  // Backend can override
      admitted: false
    };

    this.patientService.updatePatient(this.patientId, updatedPatient).subscribe({
      next: () => {
        this.successMessage = '✅ Profile updated successfully!';
        this.errorMessage = '';
      },
      error: () => {
        this.successMessage = '';
        this.errorMessage = '❌ Failed to update profile.';
      }
    });
  }
}
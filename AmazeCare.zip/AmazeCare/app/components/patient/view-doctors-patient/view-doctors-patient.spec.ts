import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewDoctorsPatient } from './view-doctors-patient';

describe('ViewDoctorsPatient', () => {
  let component: ViewDoctorsPatient;
  let fixture: ComponentFixture<ViewDoctorsPatient>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ViewDoctorsPatient]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewDoctorsPatient);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

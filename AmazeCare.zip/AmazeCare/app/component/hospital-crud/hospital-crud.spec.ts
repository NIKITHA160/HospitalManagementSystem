import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HospitalCrud } from './hospital-crud';

describe('HospitalCrud', () => {
  let component: HospitalCrud;
  let fixture: ComponentFixture<HospitalCrud>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HospitalCrud]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HospitalCrud);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

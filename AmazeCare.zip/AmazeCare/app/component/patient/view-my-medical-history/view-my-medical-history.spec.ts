import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewMyMedicalHistory } from './view-my-medical-history';

describe('ViewMyMedicalHistory', () => {
  let component: ViewMyMedicalHistory;
  let fixture: ComponentFixture<ViewMyMedicalHistory>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ViewMyMedicalHistory]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewMyMedicalHistory);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

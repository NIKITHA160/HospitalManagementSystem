import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewPatientProfile } from './view-patient-profile';

describe('ViewPatientProfile', () => {
  let component: ViewPatientProfile;
  let fixture: ComponentFixture<ViewPatientProfile>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ViewPatientProfile]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewPatientProfile);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

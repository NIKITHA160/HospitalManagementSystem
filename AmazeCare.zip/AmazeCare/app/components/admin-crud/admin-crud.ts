import { CommonModule } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { Admin } from '../../model/admin';
import { AdminService } from '../../service/admin-service';

@Component({
  selector: 'app-admin-crud',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatInputModule,
    MatButtonModule
  ],
  templateUrl: './admin-crud.html',
  styleUrl: './admin-crud.css'
})
export class AdminCrudComponent implements OnInit {
  displayedColumns: string[] = ['id', 'name', 'email', 'contact', 'registeredOn', 'actions'];
  dataSource = new MatTableDataSource<Admin>([]);
  adminForm!: FormGroup;
  isEditing = false;
  selectedAdminId: number | null = null;
  successMessage = '';
  errorMessage = '';
  filterValue = '';

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  constructor(private adminService: AdminService, private fb: FormBuilder) {}

  ngOnInit(): void {
    this.adminForm = this.fb.group({
      fullName: ['', Validators.required],
      emailAddress: ['', [Validators.required, Validators.email]],
      contactNumber: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      loginPassword: ['', [Validators.required, Validators.minLength(6)]],
      registeredOn: ['', Validators.required]
    });
    this.loadAdmins();
  }

  loadAdmins(): void {
    this.adminService.getAllAdmins().subscribe(data => {
      this.dataSource = new MatTableDataSource(data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.filterPredicate = (admin: Admin, filter: string) => {
        const searchStr = (admin.fullName + admin.emailAddress + admin.contactNumber).toLowerCase();
        return searchStr.includes(filter.trim().toLowerCase());
      };
    });
  }

  applyFilter(): void {
    this.dataSource.filter = this.filterValue.trim().toLowerCase();
  }

  editAdmin(admin: Admin): void {
    this.isEditing = true;
    this.selectedAdminId = admin.adminId;
    this.adminForm.patchValue(admin);
  }

  deleteAdmin(id: number): void {
    if (confirm('Are you sure you want to delete this admin?')) {
      this.adminService.deleteAdmin(id).subscribe(() => this.loadAdmins());
    }
  }

  onSubmit(): void {
    if (this.adminForm.invalid) {
      this.errorMessage = 'Please fill in all required fields correctly.';
      return;
    }

    const adminData: Admin = this.adminForm.value;
    adminData.registeredOn = new Date(adminData.registeredOn);

    if (this.isEditing && this.selectedAdminId !== null) {
      this.adminService.updateAdmin(this.selectedAdminId, adminData).subscribe(() => {
        this.successMessage = 'Admin updated successfully!';
        this.resetForm();
        this.loadAdmins();
      });
    } else {
      adminData.adminId = 0;
      this.adminService.addAdmin(adminData).subscribe(() => {
        this.successMessage = 'Admin added successfully!';
        this.resetForm();
        this.loadAdmins();
      });
    }
  }

  resetForm(): void {
    this.adminForm.reset();
    this.isEditing = false;
    this.selectedAdminId = null;
    this.successMessage = '';
    this.errorMessage = '';
  }
}

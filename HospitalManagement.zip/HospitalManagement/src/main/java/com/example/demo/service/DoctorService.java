package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Doctor;
import com.example.demo.model.UserData;
import com.example.demo.repo.DoctorRepository;
import com.example.demo.repo.UserDataRepository;

@Service
public class DoctorService {

    @Autowired
    private DoctorRepository doctorRepository;

    @Autowired
    private UserDataRepository userDataRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    public Doctor addDoctor(Doctor doctor) {
        
        String encodedPassword = passwordEncoder.encode(doctor.getLoginPassword());
        doctor.setLoginPassword(encodedPassword);

       
        Doctor savedDoctor = doctorRepository.save(doctor);

        
        UserData user = new UserData();
        user.setName(savedDoctor.getFullName());
        user.setEmail(savedDoctor.getEmailAddress());
        user.setPassword(encodedPassword);
        user.setRoles("ROLE_DOCTOR");
        userDataRepository.save(user);

        return savedDoctor;
    }

    public List<Doctor> showAllDoctors() {
        return doctorRepository.findAll();
    }

    public List<Doctor> showByDepartment(String department) {
        List<Doctor> list = doctorRepository.findByDepartment(department);
        if (list.isEmpty()) {
            throw new ResourceNotFoundException("No doctors found in department: " + department);
        }
        return list;
    }

    public List<Doctor> searchByName(String name) {
        List<Doctor> list = doctorRepository.findByFullNameContainingIgnoreCase(name);
        if (list.isEmpty()) {
            throw new ResourceNotFoundException("No doctor found with name containing: " + name);
        }
        return list;
    }
    public List<Doctor> getDoctorsByHospital(Long hospitalId) {
        List<Doctor> list = doctorRepository.findByHospitalId(hospitalId);
        if (list.isEmpty()) {
            throw new ResourceNotFoundException("No doctors found for hospital ID: " + hospitalId);
        }
        return list;
    }
    public Doctor updateDoctor(int id, Doctor updatedDoctor) {
        Doctor existingDoctor = doctorRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Doctor not found"));

        existingDoctor.setFullName(updatedDoctor.getFullName());
        existingDoctor.setDepartment(updatedDoctor.getDepartment());
        existingDoctor.setDesignation(updatedDoctor.getDesignation());
        existingDoctor.setEmailAddress(updatedDoctor.getEmailAddress());
        existingDoctor.setMobileNumber(updatedDoctor.getMobileNumber());
        existingDoctor.setQualification(updatedDoctor.getQualification());
        existingDoctor.setYearsOfExperience(updatedDoctor.getYearsOfExperience());
        existingDoctor.setLoginPassword(updatedDoctor.getLoginPassword());
        existingDoctor.setHospitalId(updatedDoctor.getHospitalId());

        
        userDataRepository.findByEmail(updatedDoctor.getEmailAddress())
            .ifPresent(user -> {
                user.setName(updatedDoctor.getFullName());
                user.setEmail(updatedDoctor.getEmailAddress());
                userDataRepository.save(user);
            });

        return doctorRepository.save(existingDoctor);
    }

    public Doctor getDoctorByEmail(String email) {
        Doctor doctor = doctorRepository.findByEmailAddress(email);
        if (doctor == null) {
            throw new ResourceNotFoundException("Doctor not found with email: " + email);
        }
        return doctor;
    }
    public void deleteDoctorById(int id) {
        Doctor doctor = doctorRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Doctor not found with ID: " + id));
        
        
        doctorRepository.deleteById(id);

        
        userDataRepository.findByEmail(doctor.getEmailAddress())
            .ifPresent(user -> userDataRepository.delete(user));
    }


    



    
}


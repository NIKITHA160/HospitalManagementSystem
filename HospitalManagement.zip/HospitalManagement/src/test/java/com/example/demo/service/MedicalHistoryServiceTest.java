package com.example.demo.service;

import com.example.demo.model.MedicalHistory;
import com.example.demo.repo.MedicalHistoryRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.*;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class MedicalHistoryServiceTest {

    @Mock private MedicalHistoryRepository medicalHistoryRepository;

    @InjectMocks private MedicalHistoryService medicalHistoryService;

    private MedicalHistory record;

    @Before
    public void setUp() {
        record = new MedicalHistory();
        record.setRecordId(1);
        record.setDiagnosis("Flu");
    }

    @Test
    public void testAddMedicalRecord() {
        when(medicalHistoryRepository.save(record)).thenReturn(record);
        MedicalHistory result = medicalHistoryService.addMedicalRecord(record);
        assertEquals("Flu", result.getDiagnosis());
    }

    @Test
    public void testDeleteMedicalRecord() {
        when(medicalHistoryRepository.existsById(1)).thenReturn(true);
        boolean deleted = medicalHistoryService.deleteMedicalRecord(1);
        assertTrue(deleted);
        verify(medicalHistoryRepository).deleteById(1);
    }
}


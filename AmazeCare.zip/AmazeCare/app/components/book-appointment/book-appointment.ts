import { Component, OnInit } from '@angular/core';
import {
  FormBuilder, FormGroup, Validators, FormsModule, ReactiveFormsModule
} from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { PatientService } from '../../service/patient-service';
import { Appointment, AppointmentStatus } from '../../model/appointment';

@Component({
  selector: 'app-book-appointment',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './book-appointment.html',
  styleUrls: ['./book-appointment.css']
})
export class BookAppointmentComponent implements OnInit {
  appointmentForm!: FormGroup;
  successMessage = '';
  errorMessage = '';
  patientId!: number;
  doctorIdFromQuery!: number;

  constructor(
    private fb: FormBuilder,
    private patientService: PatientService,
    private http: HttpClient,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.doctorIdFromQuery = +params['doctorId'];
    });

    this.appointmentForm = this.fb.group({
      preferredDate: ['', Validators.required],
      preferredTime: ['', Validators.required],
      natureOfVisit: ['', Validators.required],
      symptoms: ['', Validators.required]
    });

    const email = localStorage.getItem('userEmail');
    if (email) {
      this.patientService.getPatientByEmail(email).subscribe({
        next: (patient) => {
          this.patientId = patient.patientId;
        },
        error: () => {
          this.errorMessage = '❌ Failed to load patient data.';
        }
      });
    } else {
      this.errorMessage = '❌ Email not found. Please login again.';
    }
  }

  onSubmit(): void {
    if (this.appointmentForm.invalid || !this.patientId || !this.doctorIdFromQuery) {
      this.errorMessage = '❌ Please complete all fields correctly.';
      return;
    }

    const formValues = this.appointmentForm.value;
    const preferredDatetime = new Date(`${formValues.preferredDate}T${formValues.preferredTime}`);

    const newAppointment: Appointment = {
      appointmentId: 0,
      patientId: this.patientId,
      doctorId: this.doctorIdFromQuery,
      preferredDatetime,
      natureOfVisit: formValues.natureOfVisit,
      symptoms: formValues.symptoms,
      status: AppointmentStatus.pending
    };

    const token = localStorage.getItem('jwt');

    if (!token || token.trim() === '' || token.split('.').length !== 3) {
      this.errorMessage = '❌ Invalid or missing token. Please login again.';
      return;
    }

    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });

    this.http.post<Appointment>(
      'http://localhost:8080/addAppointment',
      newAppointment,
      { headers }
    ).subscribe({
      next: () => {
        this.successMessage = '✅ Appointment booked successfully!';
        this.errorMessage = '';
        this.appointmentForm.reset();
      },
      error: (err) => {
        console.error(err);
        this.successMessage = '';
        this.errorMessage = '❌ Booking failed. Try again.';
      }
    });
  }
}

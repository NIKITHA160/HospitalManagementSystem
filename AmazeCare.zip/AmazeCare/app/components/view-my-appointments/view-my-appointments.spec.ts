import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewMyAppointments } from './view-my-appointments';

describe('ViewMyAppointments', () => {
  let component: ViewMyAppointments;
  let fixture: ComponentFixture<ViewMyAppointments>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ViewMyAppointments]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewMyAppointments);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateMedicalRecord } from './update-medical-record';

describe('UpdateMedicalRecord', () => {
  let component: UpdateMedicalRecord;
  let fixture: ComponentFixture<UpdateMedicalRecord>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UpdateMedicalRecord]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdateMedicalRecord);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

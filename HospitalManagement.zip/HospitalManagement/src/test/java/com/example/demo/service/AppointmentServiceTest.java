package com.example.demo.service;

import com.example.demo.model.Appointment;
import com.example.demo.model.AppointmentStatus;
import com.example.demo.repo.AppointmentRepository;
import com.example.demo.exception.ResourceNotFoundException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;

import java.sql.Timestamp;
import java.util.*;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class AppointmentServiceTest {

    @Mock private AppointmentRepository appointmentRepository;

    @InjectMocks private AppointmentService appointmentService;

    private Appointment appointment;

    @Before
    public void setUp() {
        appointment = new Appointment();
        appointment.setAppointmentId(1);
        appointment.setSymptoms("Fever");
        appointment.setPreferredDatetime(Timestamp.valueOf("2025-07-20 10:00:00"));
        appointment.setStatus(AppointmentStatus.pending);
    }

    @Test
    public void testAddAppointment() {
        when(appointmentRepository.save(any())).thenReturn(appointment);
        Appointment result = appointmentService.addAppointment(appointment);
        assertEquals(AppointmentStatus.pending, result.getStatus());
    }

    @Test
    public void testCancelAppointment() {
        when(appointmentRepository.findById(1)).thenReturn(Optional.of(appointment));
        String msg = appointmentService.cancelAppointment(1);
        assertEquals("Appointment cancelled successfully.", msg);
    }
}
